package com.mkmd.singleAndThread.hungry1.test;

/**
 * 立即加载就是使用类的时候已经将对象创建完毕，常见的实现办法就是直接new实例化
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		MyThread m1 = new MyThread();
		MyThread m2 = new MyThread();
		MyThread m3 = new MyThread();
		m1.start();
		m2.start();
		m3.start();

	}

}
