package com.mkmd.singleAndThread.static1.test;

/**
 * 使用static代码实现单例模式
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		MyThread m1 = new MyThread();
		MyThread m2 = new MyThread();
		MyThread m3 = new MyThread();
		m1.start();
		m2.start();
		m3.start();

	}

}
