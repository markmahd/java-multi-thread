package com.mkmd.singleAndThread.enum1.test;

/**
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		MyThread m1 = new MyThread();
		MyThread m2 = new MyThread();
		MyThread m3 = new MyThread();
		m1.start();
		m2.start();
		m3.start();

	}

}
