package com.mkmd.singleAndThread.enum1.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public enum Myobject {
	connertionFactory;
	private Connection connection;

	private Myobject() {
		try {
			System.out.println("调用Myobject的构造");
			String url = "jdbc:mysql://127.0.0.1:3306/mysql?useUnicode=true&characterEncoding=utf-8&autoReconnect=true&zeroDateTimeBehavior=convertToNull";
			String username = "root";
			String password = "123456";
			// 1.加载驱动程序
			Class.forName("com.mysql.jdbc.Driver");
			// 2.获得数据库链接
			Connection conn = DriverManager.getConnection(url, username, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public Connection getConnecction() {
		return connection;
	}

}
