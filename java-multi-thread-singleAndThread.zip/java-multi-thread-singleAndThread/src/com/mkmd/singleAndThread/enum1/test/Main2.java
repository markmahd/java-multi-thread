package com.mkmd.singleAndThread.enum1.test;

/**
 * 
 * 
 * @author mahd
 *
 */
public class Main2 {

	public static void main(String[] args) {
		MyThread2 m1 = new MyThread2();
		MyThread2 m2 = new MyThread2();
		MyThread2 m3 = new MyThread2();
		m1.start();
		m2.start();
		m3.start();

	}

}
