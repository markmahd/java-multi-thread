package com.mkmd.singleAndThread.lazy1.test;

/**
 * 错误单例--synchronized方法单例成功，但效率较低
 * 
 * @author mahd
 *
 */
public class Main3 {

	public static void main(String[] args) {
		MyThread3 m1 = new MyThread3();
		m1.start();
		MyThread3 m2 = new MyThread3();
		m2.start();
		MyThread3 m3 = new MyThread3();
		m3.start();
	}

}
