package com.mkmd.singleAndThread.lazy1.test;

/**
 * 延迟加载就是在调用get()方法是实例才被创建，常见的实现方法是在get()方法中进行new实例化
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		MyThread m1 = new MyThread();
		m1.start();
	
	}

}
