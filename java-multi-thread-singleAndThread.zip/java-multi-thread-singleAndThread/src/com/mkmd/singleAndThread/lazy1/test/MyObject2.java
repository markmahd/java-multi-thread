package com.mkmd.singleAndThread.lazy1.test;

public class MyObject2 {
	private static MyObject2 myObject;

	private MyObject2() {
	}

	public static MyObject2 getInstance() {
		// 延迟加载
		try {
			if (myObject != null) {
			} else {
				Thread.sleep(3000);
				myObject = new MyObject2();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return myObject;
	}

}
