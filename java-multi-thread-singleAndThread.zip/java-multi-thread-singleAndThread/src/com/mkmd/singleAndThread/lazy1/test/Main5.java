package com.mkmd.singleAndThread.lazy1.test;

/**
 * 成功单例--DCL双检查锁机制
 * 
 * @author mahd
 *
 */
public class Main5 {

	public static void main(String[] args) {
		MyThread5 m1 = new MyThread5();
		m1.start();
		MyThread5 m2 = new MyThread5();
		m2.start();
		MyThread5 m3 = new MyThread5();
		m3.start();
	}

}
