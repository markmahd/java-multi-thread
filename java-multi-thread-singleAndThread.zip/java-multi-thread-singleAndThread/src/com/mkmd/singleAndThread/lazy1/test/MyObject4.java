package com.mkmd.singleAndThread.lazy1.test;

public class MyObject4 {
	private static MyObject4 myObject;

	private MyObject4() {
	}

	// 同步方法
	public static MyObject4 getInstance() {
		// 延迟加载
		try {
			//synchronized (MyObject.class) {
				if (myObject != null) {
				} else {
					Thread.sleep(3000);
					synchronized (MyObject.class) {
						myObject = new MyObject4();
					}
				}
			//}

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return myObject;
	}

}
