package com.mkmd.singleAndThread.lazy1.test;

/**
 * 错误单例--出现多例
 * 
 * @author mahd
 *
 */
public class Main2 {

	public static void main(String[] args) {
		MyThread2 m1 = new MyThread2();
		m1.start();
		MyThread2 m2 = new MyThread2();
		m2.start();
		MyThread2 m3 = new MyThread2();
		m3.start();
	}

}
