package com.mkmd.singleAndThread.lazy1.test;

public class MyObject5 {
	private volatile static MyObject5 myObject;

	private MyObject5() {
	}

	// 同步方法
	public static MyObject5 getInstance() {
		// 延迟加载
		try {
			//synchronized (MyObject.class) {
				if (myObject != null) {
				} else {
					Thread.sleep(3000);
					synchronized (MyObject.class) {
						myObject = new MyObject5();
					}
				}
			//}

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return myObject;
	}

}
