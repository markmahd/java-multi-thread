package com.mkmd.singleAndThread.lazy1.test;

/**
 * 错误单例--synchronized代码块单例成功，但效率较低
 * 
 * @author mahd
 *
 */
public class Main4 {

	public static void main(String[] args) {
		MyThread4 m1 = new MyThread4();
		m1.start();
		MyThread4 m2 = new MyThread4();
		m2.start();
		MyThread4 m3 = new MyThread4();
		m3.start();
	}

}
