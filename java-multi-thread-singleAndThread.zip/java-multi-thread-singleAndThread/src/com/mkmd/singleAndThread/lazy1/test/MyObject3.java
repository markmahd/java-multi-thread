package com.mkmd.singleAndThread.lazy1.test;

public class MyObject3 {
	private static MyObject3 myObject;

	private MyObject3() {
	}

	// 同步方法
	synchronized public static MyObject3 getInstance() {
		// 延迟加载
		try {
			if (myObject != null) {
			} else {
				Thread.sleep(3000);
				myObject = new MyObject3();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return myObject;
	}

}
