package com.mkmd.singleAndThread.InnerClass1.test;

public class MyThread extends Thread {

	@Override
	public void run() {
		System.out.println(MyObject.getInstance().hashCode());
	}

}
