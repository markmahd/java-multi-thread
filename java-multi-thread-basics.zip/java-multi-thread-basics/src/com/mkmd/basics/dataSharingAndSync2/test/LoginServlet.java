package com.mkmd.basics.dataSharingAndSync2.test;

/**
 * 本类模拟一个Servlet组件
 * 
 * @author mahd
 *
 */
public class LoginServlet {
	private static String usernameRef;
	private static String passwordRef;

	// 线程不安全
	// public static void doPost(String username, String password) {
	// try {
	// usernameRef = username;
	// if (username.equals("a")) {
	//
	// Thread.sleep(5000);
	//
	// }
	// passwordRef = password;
	// System.out.println("username=" + usernameRef + ",password=" + password);
	// } catch (InterruptedException e) {
	// e.printStackTrace();
	// }
	// }

	// 排队进入
	synchronized public static void doPost(String username, String password) {
		try {
			usernameRef = username;
			if (username.equals("a")) {

				Thread.sleep(5000);

			}
			passwordRef = password;
			System.out.println("username=" + usernameRef + ",password=" + password);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
