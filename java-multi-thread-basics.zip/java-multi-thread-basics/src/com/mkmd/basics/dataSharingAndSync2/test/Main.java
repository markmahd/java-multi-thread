package com.mkmd.basics.dataSharingAndSync2.test;

/**
 * LoginServlet类中doPost方法在没有加synchronized时，是线程非安全的 ，但加上synchronized后，排队进入
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		ALogin a = new ALogin();
		a.start();
		BLogin b = new BLogin();
		b.start();
	}

}
