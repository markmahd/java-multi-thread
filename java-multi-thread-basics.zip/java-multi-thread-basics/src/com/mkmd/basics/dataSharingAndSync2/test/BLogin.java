package com.mkmd.basics.dataSharingAndSync2.test;

public class BLogin extends Thread {
	@Override
	public void run() {
		LoginServlet.doPost("b", "bb");
	}

}
