package com.mkmd.basics.dataSharingAndSync2.test;

public class ALogin extends Thread {
	@Override
	public void run() {
		LoginServlet.doPost("a", "aa");
	}

}
