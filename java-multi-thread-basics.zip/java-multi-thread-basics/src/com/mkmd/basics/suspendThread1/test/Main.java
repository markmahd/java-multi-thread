package com.mkmd.basics.suspendThread1.test;

/**
 * 
 * 暂停线程意味着此线程还可以恢复运行。在Java多线程中，可以使用suspend()方法暂停线程，使用resume()方法恢复线程执行
 * 
 * @author mahd
 *
 */
public class Main {
	public static void main(String[] args) {
		try {
			MyThread thread = new MyThread();
			thread.start();
			Thread.sleep(5000);
			thread.interrupt();
			// A段
			thread.suspend();
			System.out.println("A=" + System.currentTimeMillis() + " i=" + thread.getI());
			Thread.sleep(5000);
			System.out.println("A=" + System.currentTimeMillis() + " i=" + thread.getI());
			// B段
			thread.resume();
			Thread.sleep(5000);
			// C段
			thread.suspend();
			System.out.println("B=" + System.currentTimeMillis() + " i=" + thread.getI());
			Thread.sleep(5000);
			System.out.println("B=" + System.currentTimeMillis() + " i=" + thread.getI());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
}
