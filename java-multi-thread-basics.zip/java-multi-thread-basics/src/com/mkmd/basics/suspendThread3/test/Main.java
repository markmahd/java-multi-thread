package com.mkmd.basics.suspendThread3.test;

/**
 * 
 * suspend和resume方法的缺点--不同步：容易出现因为线程的暂停而导致数据不同步的情况
 * 
 * @author mahd
 *
 */
public class Main {
	public static void main(String[] args) throws InterruptedException {
		final MyObject object = new MyObject();
		Thread th1 = new Thread() {
			@Override
			public void run() {
				object.setValue("a", "aa");
			}
		};
		th1.setName("a");
		th1.start();
		th1.sleep(1000);
		Thread th2 = new Thread() {
			@Override
			public void run() {
				object.printUsernamePassword();
			}
		};
		th2.start();

	}
}
