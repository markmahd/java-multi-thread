package com.mkmd.basics.println.test;

/**
 * 虽然println是线程安全的，但是i--操作全是在进入println方法前发生的，所以有发生非线程安全问题的概率
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		MyThread run = new MyThread();
		Thread t1 = new Thread(run);
		Thread t2 = new Thread(run);
		Thread t3 = new Thread(run);
		Thread t4 = new Thread(run);
		Thread t5 = new Thread(run);
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();

	}

}
