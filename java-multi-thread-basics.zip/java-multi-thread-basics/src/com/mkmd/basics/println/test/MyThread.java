package com.mkmd.basics.println.test;

public class MyThread extends Thread {
	private int i = 5;

	// 非线程安全
	// @Override
	// public void run() {
	// System.out.println("i=" + (i--) + ",threadName=" +
	// Thread.currentThread().getName());
	// }

	// 排队进入

	@Override
	synchronized public void run() {
		System.out.println("i=" + (i--) + "threadName=" + Thread.currentThread().getName());
	}

}
