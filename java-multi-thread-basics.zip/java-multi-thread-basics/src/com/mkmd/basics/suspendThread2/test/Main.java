package com.mkmd.basics.suspendThread2.test;

/**
 * 
 * suspend和resume方法的缺点--独占例子（1）：在使用suspend和resume方法时，如果使用不当，极易造成公共的同步对象的独占，使得其他线程无法访问公共同步对象
 * 
 * @author mahd
 *
 */
public class Main {
	public static void main(String[] args) {
		try {
			final SynchronizedObject object = new SynchronizedObject();
			Thread th1 = new Thread() {
				@Override
				public void run() {
					object.printString();
				}
			};
			th1.setName("a");
			th1.start();
			th1.sleep(1000);
			Thread th2 = new Thread() {
				@Override
				public void run() {
					System.out.println("th2启动了，但是进不了printSting()方法！只打印1个begin");
					System.out.println("因为printString()方法被a线程锁定并且永远suspend暂停了");
					object.printString();
				}
			};
			th2.start();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
}
