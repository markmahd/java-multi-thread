package com.mkmd.basics.suspendThread2.test;

/**
 * 
 * suspend和resume方法的缺点--独占例子（2）：main()方法的 println（）被独占
 * 
 * @author mahd
 *
 */
public class Main2 {
	public static void main(String[] args) {
		try {
			MyThread2 thread = new MyThread2();
			thread.start();
			thread.sleep(1000);
			thread.suspend();
			System.out.println("main end");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
}
