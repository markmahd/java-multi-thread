package com.mkmd.basics.stopThread4.test;

/**
 * 使用stop()方法停止线程则是非常暴力的
 * 
 * @author mahd
 *
 */
public class Main {
	public static void main(String[] args) {
		try {
			MyThread thread = new MyThread();
			thread.start();
			Thread.sleep(8000);

			thread.stop();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
