package com.mkmd.basics.stopThread4.test;

public class MyThread extends Thread {
	private int i = 0;

	@Override
	public void run() {
		try {
			while (true) {
				i++;
				System.out.println("i=" + i);
				Thread.sleep(200000);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
