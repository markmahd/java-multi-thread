package com.mkmd.basics.currentThread3.test;

/**
 * start方法执行结果与run方法执行结果区别
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		CountOperate c = new CountOperate();
		Thread t1 = new Thread(c);
		t1.setName("A");
		t1.start();
	}

}
