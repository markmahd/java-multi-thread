package com.mkmd.basics.yield.test;

/**
 * yield()方法的作用是放弃当前的CPU资源，将他让给其他的任务去占用CPU执行时间。但放弃的时间不确定，有可能刚刚放弃马上又获得CPU时间片
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		MyThread thread = new MyThread();
		thread.start();
	}

}
