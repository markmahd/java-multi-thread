package com.mkmd.basics.runnableImpl1.test;

/**
 * 使用继承Thread类的方式来开发多线程应用程序在设计上有局限性，因为Java是单继承，但可以使用实现Runnable接口的方式来实现多线程技术
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		Runnable runnable = new MyRunnable();
		Thread thread = new Thread(runnable);
		thread.start();
		System.out.println("运行结束！");

	}

}
