package com.mkmd.basics.runnableImpl1.test;

public class MyRunnable implements Runnable {

	@Override
	public void run() {
		System.out.println("运行中。。。");

	}

}
