package com.mkmd.basics.dataSharing1.test;

/**
 * 线程之间独立，不共享数据
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		MyThread a = new MyThread("A");
		MyThread b = new MyThread("B");
		MyThread c = new MyThread("C");
		a.start();
		b.start();
		c.start();
	}
}
