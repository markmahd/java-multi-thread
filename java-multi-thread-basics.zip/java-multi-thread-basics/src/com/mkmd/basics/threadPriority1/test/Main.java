package com.mkmd.basics.threadPriority1.test;

/**
 * 线程可以划分优先级，优先级较高的线程得到的CPU资源较多，也就是CPU优先执行优先级较高的线程对象中的任务
 * 
 * 设置线程优先级有助于帮“线程规划器”确定下一次选择哪一个线程来优先执行
 * 
 * 在Java中，线程优先级分为1~10这10个等级，如果小于1或大于10，则JDK抛出异常throw new
 * IllengalArgumentException()
 * 
 * 1、继承特性：在Java中，线程具有继承性，比如A线程启动B线程，则B线程的优先级与A线程的优先级是一样的
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		System.out.println("main thread begin priority=" + Thread.currentThread().getPriority());
		Thread.currentThread().setPriority(6);
		System.out.println("main thread end priority=" + Thread.currentThread().getPriority());
		MyThread1 th1 = new MyThread1();
		th1.start();
	}

}
