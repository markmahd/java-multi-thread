package com.mkmd.basics.dataSharingAndSync1.test;

/**
 * 线程之间，共享数据（myThread）,同步
 * 
 * 通过在run方法前加入synchronized关键字，使多个线程在执行run方法时，一排队的方式进行处理
 * 
 * 当一个线程想要执行同步方法里面的代码时，线程首先尝试去拿这把锁，如果能够拿到这把锁，那么这个线程就可以执行synchronized里面的代码。
 * 如果不能拿到这把锁，那么这个线程就会不断尝试拿到这把锁，直到能够拿到为止，而且是由多个线程同时去争抢这把锁。
 * 
 * 非线程安全主要是指多个线程对同一对象中的同一个实例变量进行操作时会出现值被更改、值不同步的情况，进而影响程序的执行流程
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		MyThread myThread = new MyThread();
		Thread a = new Thread(myThread, "A");
		Thread b = new Thread(myThread, "B");
		Thread c = new Thread(myThread, "C");
		Thread d = new Thread(myThread, "D");
		Thread e = new Thread(myThread, "E");
		a.start();
		b.start();
		c.start();
		d.start();
		e.start();
	}
}
