package com.mkmd.basics.sleep.test;

/**
 * sleep方法的作用是在指定的毫秒数内让当前“正在执行的线程”休眠（暂停执行）。这个“正在执行的线程”是指this.currentThread()返回的线程
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) throws InterruptedException {
		MyThread myThread = new MyThread();
		System.out.println("myThread begin==" + System.currentTimeMillis());
		myThread.run();
		System.out.println("myThread end==" + System.currentTimeMillis());

		MyThread2 myThread2 = new MyThread2();
		System.out.println("myThread2 begin==" + System.currentTimeMillis());
		myThread2.start();
		System.out.println("myThread2 end==" + System.currentTimeMillis());
	}

}
