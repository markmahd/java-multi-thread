package com.mkmd.basics.frist.test;

public class FirstThread {

	public static void main(String[] args) {
		System.out.println(Thread.currentThread().getName());
	}

}
