package com.mkmd.basics.stopThread3.test;

/**
 * 在沉睡中停止：如果在sleep状态下停止某一线程，会进入catch语句，并且清除停止状态值，是指变成false
 * 
 * @author mahd
 *
 */
public class Main {
	public static void main(String[] args) {
		try {
			MyThread thread = new MyThread();
			thread.start();

			thread.sleep(200);

			thread.interrupt();
		} catch (InterruptedException e) {
			System.out.println("main catch");
			e.printStackTrace();
		}
		System.out.println("end");
	}
}
