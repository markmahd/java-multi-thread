package com.mkmd.basics.stopThread3.test;

/**
 * 在沉睡中停止
 * 
 * @author mahd
 *
 */
public class Main2 {
	public static void main(String[] args) {
		MyThread2 thread = new MyThread2();
		thread.start();
		thread.interrupt();
		System.out.println("end");
	}
}
