package com.mkmd.basics.currentThread2.test;

/**
 * start方法执行结果是构造方法被main线程调用；run方法被名为Thread-0的线程调用，是自动调用的
 * run方法执行结果是构造方法和run方法都是线程main调用的
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		MyThread myThread = new MyThread();
		// myThread.start();
		myThread.run();
	}

}
