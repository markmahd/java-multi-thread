package com.mkmd.basics.stopThread1.test;

/**
 * interrupt并没有停止线程
 * 
 * @author mahd
 *
 */
public class Main {
	public static void main(String[] args) {
		try {
			MyThread thread = new MyThread();
			thread.start();

			thread.sleep(2000);

			thread.interrupt();
		} catch (InterruptedException e) {
			System.out.println("main catch");
			e.printStackTrace();
		}
	}
}
