package com.mkmd.basics.stopThread1.test;

/**
 * interrupt方法测试当前线程是否已经中断。当前线程从未中断过
 * 
 * @author mahd
 *
 */
public class Main2 {
	public static void main(String[] args) {
		try {
			MyThread thread = new MyThread();
			thread.start();

			thread.sleep(1000);

			thread.interrupt();
			// Thread.currentThread().interrupt();
			System.out.println("是否停止1？=" + thread.interrupted());
			System.out.println("是否停止2？=" + thread.interrupted());
		} catch (InterruptedException e) {
			System.out.println("main catch");
			e.printStackTrace();
		}

	}
}
