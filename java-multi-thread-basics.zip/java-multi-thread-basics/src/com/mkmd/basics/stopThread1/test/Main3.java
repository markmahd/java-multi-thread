package com.mkmd.basics.stopThread1.test;

/**
 * 测试当前线程是否已经中断，线程的中断状态有interrupted方法清除，第二次放回false
 * 
 * @author mahd
 *
 */
public class Main3 {

	public static void main(String[] args) {
		Thread.currentThread().interrupt();
		System.out.println("是否停止1？=" + Thread.interrupted());
		System.out.println("是否停止2？=" + Thread.interrupted());
	}

}
