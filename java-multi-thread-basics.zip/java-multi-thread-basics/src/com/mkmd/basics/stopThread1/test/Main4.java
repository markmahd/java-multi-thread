package com.mkmd.basics.stopThread1.test;

/**
 * isInterrupted方法并没有清除状态标志
 * 
 * this.interrupted():测试当前线程是否已经是中断状态，执行后具有将状态标志置清除为false的功能
 * this.isInterrupted():测试线程Thread对象是否已经是中断状态，但不清除状态标志
 * 
 * @author mahd
 *
 */
public class Main4 {

	public static void main(String[] args) {
		try {
			MyThread thread = new MyThread();
			thread.start();

			thread.sleep(500);

			thread.interrupt();
			System.out.println("是否停止1？=" + thread.isInterrupted());
			System.out.println("是否停止2？=" + thread.isInterrupted());
		} catch (InterruptedException e) {
			System.out.println("main catch");
			e.printStackTrace();
		}
		System.out.println("end");

	}

}
