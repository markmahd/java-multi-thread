package com.mkmd.basics.daemonThread.test;

public class ThreadA extends Thread {
	private int count = 0;

	@Override
	public void run() {
		try {
			while (true) {
				count++;
				System.out.println("count=" + count);

				Thread.sleep(1000);

			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
