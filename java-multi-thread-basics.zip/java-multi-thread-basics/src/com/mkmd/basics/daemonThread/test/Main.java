package com.mkmd.basics.daemonThread.test;

/**
 * 在Java线程中有两种线程：一种是用户线程，另一种是守护线程
 * 
 * 守护线程是一种特殊的线程，它的特性有“陪伴”的含义，当继承中不存在非守护线程了，则守护线程自动销毁
 * 
 * 守护线程最典型的应用就是GC(垃圾回收器)，他就是一个很称职的守护者
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		try {
			ThreadA a = new ThreadA();
			a.setDaemon(true);
			a.start();
			Thread.sleep(5000);
			System.out.println("我离开a对象也不再打印了，也就是停止了！");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
