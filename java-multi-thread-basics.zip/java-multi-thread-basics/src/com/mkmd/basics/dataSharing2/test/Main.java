package com.mkmd.basics.dataSharing2.test;

/**
 * 线程之间，共享数据（myThread）,不同步
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		MyThread myThread = new MyThread();
		Thread a = new Thread(myThread, "A");
		Thread b = new Thread(myThread, "B");
		Thread c = new Thread(myThread, "C");
		Thread d = new Thread(myThread, "D");
		Thread e = new Thread(myThread, "E");
		a.start();
		b.start();
		c.start();
		d.start();
		e.start();
	}
}
