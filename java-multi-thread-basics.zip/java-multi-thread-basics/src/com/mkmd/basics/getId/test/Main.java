package com.mkmd.basics.getId.test;

/**
 * getId方法的作用是取得线程的唯一标识 
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		Thread runThread = Thread.currentThread();
		System.out.println(runThread.getName() + " " + runThread.getId());
	}

}
