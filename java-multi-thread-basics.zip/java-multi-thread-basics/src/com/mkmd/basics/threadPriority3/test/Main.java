package com.mkmd.basics.threadPriority3.test;

/**
 * 3、随机性：不要把线程的优先级与运行结果的顺序作为衡量标准，优先级较高的线程不一定每一次都先执行完run方法中的任务。
 * 也就是说，线程的优先级与打印顺序无关，不要讲这两者的关系关联，潭门的关系具有不确定性和随机性
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		for (int i = 0; i < 5; i++) {
			MyThread1 thread1 = new MyThread1();
			thread1.setPriority(5);
			thread1.start();
			MyThread2 thread2 = new MyThread2();
			thread2.setPriority(6);
			thread2.start();

		}

	}

}
