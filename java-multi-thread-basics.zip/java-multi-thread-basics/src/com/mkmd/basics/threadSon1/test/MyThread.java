package com.mkmd.basics.threadSon1.test;

public class MyThread extends Thread {
	@Override
	public void run() {
		super.run();
		System.out.println("MyThread");
	}
	

}
