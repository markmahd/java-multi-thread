package com.mkmd.basics.threadSon1.test;

/**
 * 代码的运行结果和代码的执行顺序活调用顺序无关
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		MyThread myThread = new MyThread();
		myThread.start();
		System.out.println("运行结束！");
	}

}
