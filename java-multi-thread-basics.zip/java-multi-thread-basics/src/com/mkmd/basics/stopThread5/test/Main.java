package com.mkmd.basics.stopThread5.test;

/**
 * 使用stop()释放锁将会给数据造成不一致性的结果。如果出现这种情况，程序处理的数据就有可能遭到破坏，最终导致程序执行的流程错误。
 * 
 * @author mahd
 *
 */
public class Main {
	public static void main(String[] args) {
		try {
			SynchronizedObject object = new SynchronizedObject();
			MyThread thread = new MyThread(object);
			thread.start();
			Thread.sleep(500);
			thread.stop();
			System.out.println(object.getUsername() + " " + object.getPassword());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
