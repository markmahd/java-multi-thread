package com.mkmd.basics.isAlive1.test;

/**
 * isAlive方法是判断当前线程是否处于活动状态
 * 
 * 活动状态就是线程已经启动尚未终止。线程处于正在运行或准备 开始运行的状态，就认为线程是“存活”的
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) throws InterruptedException {
		MyThread myThread = new MyThread();
		System.out.println("begin==" + myThread.isAlive());
		myThread.start();
		Thread.sleep(1000);// 省略该步骤获取的接货中end==true,原因是mythraed线程还未执行完毕
		System.out.println("end==" + myThread.isAlive());
	}

}
