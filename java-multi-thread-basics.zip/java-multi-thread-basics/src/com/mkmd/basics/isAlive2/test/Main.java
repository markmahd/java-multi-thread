package com.mkmd.basics.isAlive2.test;

/**
 * start方法执行结果与run方法执行结果区别
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		CountOperate c = new CountOperate();
		Thread t1 = new Thread(c);
		System.out.println("main begin t1 isAlive=" + t1.isAlive());
		t1.setName("A");
		t1.start();
		System.out.println("main end t1 isAlive=" + t1.isAlive());// 值为true 原因是线程未终止
	}

}
