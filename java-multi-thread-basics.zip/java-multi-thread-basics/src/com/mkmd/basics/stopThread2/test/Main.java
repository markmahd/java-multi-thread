package com.mkmd.basics.stopThread2.test;

/**
 * 虽然停止了线程，但是for后面的语句还是会继续执行
 * 
 * @author mahd
 *
 */
public class Main {
	public static void main(String[] args) {
		try {
			MyThread thread = new MyThread();
			thread.start();

			thread.sleep(2000);

			thread.interrupt();
		} catch (InterruptedException e) {
			System.out.println("main catch");
			e.printStackTrace();
		}
		System.out.println("end");
	}
}
