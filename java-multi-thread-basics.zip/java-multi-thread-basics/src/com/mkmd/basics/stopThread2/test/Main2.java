package com.mkmd.basics.stopThread2.test;

/**
 * for后又继续运行，线程并未停止
 * 
 * @author mahd
 *
 */
public class Main2 {
	public static void main(String[] args) {
		try {
			MyThread2 thread = new MyThread2();
			thread.start();

			thread.sleep(2000);

			thread.interrupt();
		} catch (InterruptedException e) {
			System.out.println("main catch");
			e.printStackTrace();
		}
		System.out.println("end");
	}
}
