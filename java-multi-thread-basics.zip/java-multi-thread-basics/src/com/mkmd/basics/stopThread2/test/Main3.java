package com.mkmd.basics.stopThread2.test;

/**
 * 线程停止--异常法
 * 
 * @author mahd
 *
 */
public class Main3 {
	public static void main(String[] args) {
		try {
			MyThread3 thread = new MyThread3();
			thread.start();

			thread.sleep(2000);

			thread.interrupt();
		} catch (InterruptedException e) {
			System.out.println("main catch");
			e.printStackTrace();
		}
		System.out.println("end");
	}
}
