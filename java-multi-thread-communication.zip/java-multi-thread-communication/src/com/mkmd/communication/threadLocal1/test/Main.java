package com.mkmd.communication.threadLocal1.test;

/**
 * 类Threadlocal解决的是变量在不同线程间的隔离性，也就是不同线程拥有自己的值， 不同线程中的值是可以放入Threadlocal类中进行保存的
 * ThreadLocalExt类继承Threadlocal，是为了重写initialValue方法，使Threadlocal变量有初始值，避免get()为null的情况出现
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) throws InterruptedException {
		for (int i = 0; i < 10; i++) {
			System.out.println("在Main线程中取值=" + Tools.tl.get());
			Thread.sleep(100);

		}
		Thread.sleep(5000);
		ThreadA ta = new ThreadA();
		ta.start();

	}

}
