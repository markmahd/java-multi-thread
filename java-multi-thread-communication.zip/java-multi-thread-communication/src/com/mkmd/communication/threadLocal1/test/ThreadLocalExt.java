package com.mkmd.communication.threadLocal1.test;

import java.util.Date;

public class ThreadLocalExt extends ThreadLocal {

	@Override
	protected Object initialValue() {
		return new Date().getTime();
	}

}
