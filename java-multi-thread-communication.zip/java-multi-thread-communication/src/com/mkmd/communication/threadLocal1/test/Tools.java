package com.mkmd.communication.threadLocal1.test;

public class Tools {
	public static ThreadLocalExt tl = new ThreadLocalExt();
}
