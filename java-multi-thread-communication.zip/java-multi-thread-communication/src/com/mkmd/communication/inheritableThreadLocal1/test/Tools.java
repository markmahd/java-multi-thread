package com.mkmd.communication.inheritableThreadLocal1.test;

public class Tools {
	public static InheritableThreadLocalExt tl = new InheritableThreadLocalExt();
}
