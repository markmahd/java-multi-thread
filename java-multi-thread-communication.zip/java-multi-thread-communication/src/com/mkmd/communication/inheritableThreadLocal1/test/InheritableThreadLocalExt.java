package com.mkmd.communication.inheritableThreadLocal1.test;

import java.util.Date;

public class InheritableThreadLocalExt extends InheritableThreadLocal {

	@Override
	protected Object childValue(Object arg0) {
		return arg0 + "我在子线程加的~";
	}

	@Override
	protected Object initialValue() {
		return new Date().getTime();
	}

}
