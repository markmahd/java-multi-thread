package com.mkmd.communication.inheritableThreadLocal1.test;

/**
 * 使用InheritableThreadLocal类可以让子线程从父线程中取值。但在使用InheritableThreadLocal类需要注意一点的是，如果子线程在取值的同时，
 * 主线程将InheritableThreadLocal中的值进行修改，那么子线程取得的值还是旧值。
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) throws InterruptedException {
		for (int i = 0; i < 10; i++) {
			System.out.println("在Main线程中取值=" + Tools.tl.get());
			Thread.sleep(100);

		}
		Thread.sleep(5000);
		ThreadA ta = new ThreadA();
		ta.start();

	}

}
