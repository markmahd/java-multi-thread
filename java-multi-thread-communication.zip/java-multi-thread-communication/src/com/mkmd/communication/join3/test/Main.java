package com.mkmd.communication.join3.test;

/**
 * 方法join(long)中的参数是设定等待时间
 * 方法join(long)的功能在内部使用wait(long)方法来实现的，所以join(long)方法具有释放锁的特点
 * 而sleep(long)方法不释放锁
 * 
 * 
 * 方法join()提前运行易出现意外
 * 
 * @author mahd
 *
 */
public class Main {
	public static void main(String[] args) throws InterruptedException {
		MyThread myThread = new MyThread();
		myThread.start();
		myThread.join(2000);
		System.out.println("end time=" + System.currentTimeMillis());

	}

}
