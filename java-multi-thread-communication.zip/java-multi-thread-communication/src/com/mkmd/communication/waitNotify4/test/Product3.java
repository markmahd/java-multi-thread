package com.mkmd.communication.waitNotify4.test;

public class Product3 {
	private MyStack2 myStack2;

	public Product3(MyStack2 myStack2) {
		super();
		this.myStack2 = myStack2;
	}

	public void pushService() {
		myStack2.push();
	}

}
