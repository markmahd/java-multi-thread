package com.mkmd.communication.waitNotify4.test;

/**
 * 多生产与多消费:操作值
 * 
 * @author mahd
 *
 */
public class MainMTM {

	public static void main(String[] args) throws InterruptedException {
		String lock = new String("");
		Product product = new Product(lock);
		Consume consume = new Consume(lock);

		ThreadP[] threadP = new ThreadP[2];
		ThreadC[] threadC = new ThreadC[2];
		for (int i = 0; i < 2; i++) {
			threadP[i] = new ThreadP(product);
			threadP[i].setName("生产者" + (i + 1));
			threadC[i] = new ThreadC(consume);
			threadC[i].setName("消费者" + (i + 1));
			threadP[i].start();
			threadC[i].start();
		}
		Thread.sleep(5000);
		Thread[] threadAyyay = new Thread[Thread.currentThread().getThreadGroup().activeCount()];
		Thread.currentThread().getThreadGroup().enumerate(threadAyyay);
		for (int i = 0; i < threadAyyay.length; i++) {
			System.out.println(threadAyyay[i].getName() + " " + threadAyyay[i].getState());

		}

	}

}
