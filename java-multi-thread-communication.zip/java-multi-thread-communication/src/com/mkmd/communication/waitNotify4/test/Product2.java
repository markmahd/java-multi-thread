package com.mkmd.communication.waitNotify4.test;

public class Product2 {
	private MyStack myStack;

	public Product2(MyStack myStack) {
		super();
		this.myStack = myStack;
	}
	public void pushService() {
		myStack.push();
	}


}
