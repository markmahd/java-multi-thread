package com.mkmd.communication.waitNotify4.test;

public class ThreadP3 extends Thread {
	private Product3 product;

	public ThreadP3(Product3 product) {
		super();
		this.product = product;
	}

	@Override
	public void run() {
		while (true) {
			product.pushService();
		}
	}

}
