package com.mkmd.communication.waitNotify4.test;

/**
 * 一生产与多消费
 * 
 * @author mahd
 *
 */
public class MainOTM {

	public static void main(String[] args) throws InterruptedException {
		MyStack2 myStack = new MyStack2();
		Product3 product = new Product3(myStack);
		Consume3 consume = new Consume3(myStack);
		Consume3 consume2 = new Consume3(myStack);
		Consume3 consume3 = new Consume3(myStack);
		Consume3 consume4 = new Consume3(myStack);
		Consume3 consume5 = new Consume3(myStack);
		ThreadP3 tp = new ThreadP3(product);
		ThreadC3 tc = new ThreadC3(consume);
		ThreadC3 tc2 = new ThreadC3(consume2);
		ThreadC3 tc3 = new ThreadC3(consume3);
		ThreadC3 tc4 = new ThreadC3(consume4);
		ThreadC3 tc5 = new ThreadC3(consume5);
		tp.start();
		tc.start();
		tc2.start();
		tc3.start();
		tc4.start();
		tc5.start();
	}

}
