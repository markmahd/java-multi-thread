package com.mkmd.communication.waitNotify4.test;

public class ThreadC2 extends Thread {
	private Consume2 consume;

	public ThreadC2(Consume2 consume) {
		super();
		this.consume = consume;
	}

	@Override
	public void run() {
		while (true) {
			consume.popService();
		}
	}

}
