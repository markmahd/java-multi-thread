package com.mkmd.communication.waitNotify4.test;

public class Product {
	private String lock;

	public Product(String lock) {
		super();
		this.lock = lock;
	}

	public void setvalue() {
		try {
			synchronized (lock) {
				while (!ValueObject.value.equals("")) {
					System.out.println("生产者" + Thread.currentThread().getName() + "WAITING了*");
					lock.wait();

				}
				System.out.println("生产者" + Thread.currentThread().getName() + "RUNNABLE了");
				String value = System.currentTimeMillis() + "_" + System.nanoTime();
				ValueObject.value = value;
				//lock.notify();
				lock.notifyAll();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
