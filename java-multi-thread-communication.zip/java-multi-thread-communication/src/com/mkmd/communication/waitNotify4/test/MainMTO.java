package com.mkmd.communication.waitNotify4.test;

/**
 * 多生产与一消费:操作栈
 * 
 * @author mahd
 *
 */
public class MainMTO {

	public static void main(String[] args) throws InterruptedException {
		MyStack2 myStack = new MyStack2();
		Product3 product = new Product3(myStack);
		Product3 product2 = new Product3(myStack);
		Product3 product3 = new Product3(myStack);
		Product3 product4 = new Product3(myStack);
		Product3 product5 = new Product3(myStack);
		Product3 product6 = new Product3(myStack);
		ThreadP3 tp = new ThreadP3(product);
		ThreadP3 tp2 = new ThreadP3(product2);
		ThreadP3 tp3 = new ThreadP3(product3);
		ThreadP3 tp4 = new ThreadP3(product4);
		ThreadP3 tp5 = new ThreadP3(product5);
		ThreadP3 tp6 = new ThreadP3(product6);
		tp.start();
		tp2.start();
		tp3.start();
		tp4.start();
		tp5.start();
		tp6.start();
		Consume3 consume = new Consume3(myStack);
		
		ThreadC3 tc = new ThreadC3(consume);
		tc.start();
	}

}
