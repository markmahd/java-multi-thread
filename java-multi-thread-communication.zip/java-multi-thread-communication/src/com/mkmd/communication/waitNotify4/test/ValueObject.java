package com.mkmd.communication.waitNotify4.test;

public class ValueObject {
	public static String value = "";
}
