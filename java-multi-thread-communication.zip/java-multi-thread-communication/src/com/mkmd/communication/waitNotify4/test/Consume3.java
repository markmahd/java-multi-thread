package com.mkmd.communication.waitNotify4.test;

public class Consume3 {
	private MyStack2 myStack2;

	public Consume3(MyStack2 myStack2) {
		super();
		this.myStack2 = myStack2;
	}

	public void popService() {
		System.out.println("pop=" + myStack2.pop());
	}

}
