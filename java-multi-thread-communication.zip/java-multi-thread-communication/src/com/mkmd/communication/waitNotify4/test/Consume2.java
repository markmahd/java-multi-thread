package com.mkmd.communication.waitNotify4.test;

public class Consume2 {
	private MyStack myStack;

	public Consume2(MyStack myStack) {
		super();
		this.myStack = myStack;
	}

	public void popService() {
		System.out.println("pop=" + myStack.pop());
	}

}
