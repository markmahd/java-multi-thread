package com.mkmd.communication.waitNotify4.test;

/**
 * 多生产与多消费:操作栈
 * 
 * @author mahd
 *
 */
public class MainMTM2 {

	public static void main(String[] args) throws InterruptedException {
		MyStack2 myStack = new MyStack2();
		Product3 product = new Product3(myStack);
		Product3 product2 = new Product3(myStack);
		Product3 product3 = new Product3(myStack);
		Product3 product4 = new Product3(myStack);
		Product3 product5 = new Product3(myStack);
		Product3 product6 = new Product3(myStack);
		ThreadP3 tp = new ThreadP3(product);
		ThreadP3 tp2 = new ThreadP3(product2);
		ThreadP3 tp3 = new ThreadP3(product3);
		ThreadP3 tp4 = new ThreadP3(product4);
		ThreadP3 tp5 = new ThreadP3(product5);
		ThreadP3 tp6 = new ThreadP3(product6);
		tp.start();
		tp2.start();
		tp3.start();
		tp4.start();
		tp5.start();
		tp6.start();
		Consume3 consume = new Consume3(myStack);
		Consume3 consume2 = new Consume3(myStack);
		Consume3 consume3 = new Consume3(myStack);
		Consume3 consume4 = new Consume3(myStack);
		Consume3 consume5 = new Consume3(myStack);
		Consume3 consume6 = new Consume3(myStack);
		Consume3 consume7 = new Consume3(myStack);
		Consume3 consume8 = new Consume3(myStack);
		ThreadC3 tc = new ThreadC3(consume);
		ThreadC3 tc2 = new ThreadC3(consume2);
		ThreadC3 tc3 = new ThreadC3(consume3);
		ThreadC3 tc4 = new ThreadC3(consume4);
		ThreadC3 tc5 = new ThreadC3(consume5);
		ThreadC3 tc6 = new ThreadC3(consume6);
		ThreadC3 tc7 = new ThreadC3(consume7);
		ThreadC3 tc8 = new ThreadC3(consume8);
		tc.start();
		tc2.start();
		tc3.start();
		tc4.start();
		tc5.start();
		tc6.start();
		tc7.start();
		tc8.start();
	}

}
