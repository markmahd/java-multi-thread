package com.mkmd.communication.waitNotify4.test;

public class ThreadP2 extends Thread {
	private Product2 product;

	public ThreadP2(Product2 product) {
		super();
		this.product = product;
	}

	@Override
	public void run() {
		while (true) {
			product.pushService();
		}
	}

}
