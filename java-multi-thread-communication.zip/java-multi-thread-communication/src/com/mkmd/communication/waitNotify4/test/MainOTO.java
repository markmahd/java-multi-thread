package com.mkmd.communication.waitNotify4.test;

/**
 * 一生产与一消费:操作栈
 * 
 * @author mahd
 *
 */
public class MainOTO {

	public static void main(String[] args) throws InterruptedException {
		MyStack myStack = new MyStack();
		Product2 product = new Product2(myStack);
		Consume2 consume = new Consume2(myStack);
		ThreadP2 tp = new ThreadP2(product);
		ThreadC2 tc = new ThreadC2(consume);
		tp.start();
		tc.start();
	}

}
