package com.mkmd.communication.waitNotify4.test;

public class ThreadC extends Thread {
	private Consume consume;

	public ThreadC(Consume consume) {
		super();
		this.consume = consume;
	}

	@Override
	public void run() {
		while (true) {
			consume.getValue();
		}
	}

}
