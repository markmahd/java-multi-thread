package com.mkmd.communication.waitNotify4.test;

public class ThreadP extends Thread {
	private Product product;

	public ThreadP(Product product) {
		super();
		this.product = product;
	}

	@Override
	public void run() {
		while (true) {
			product.setvalue();
		}
	}

}
