package com.mkmd.communication.waitNotify4.test;

public class ThreadC3 extends Thread {
	private Consume3 consume;

	public ThreadC3(Consume3 consume) {
		super();
		this.consume = consume;
	}

	@Override
	public void run() {
		while (true) {
			consume.popService();
		}
	}

}
