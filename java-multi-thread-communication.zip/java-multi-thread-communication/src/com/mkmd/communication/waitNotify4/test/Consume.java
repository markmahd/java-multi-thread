package com.mkmd.communication.waitNotify4.test;

public class Consume {
	private String lock;

	public Consume(String lock) {
		super();
		this.lock = lock;
	}

	public void getValue() {
		try {
			synchronized (lock) {
				while (ValueObject.value.equals("")) {
					System.out.println("消费者" + Thread.currentThread().getName() + "WAITING了+");
					lock.wait();
				}
				System.out.println("消费者" + Thread.currentThread().getName() + "RUNNABLE了");
				ValueObject.value = "";
				// lock.notify();
				lock.notifyAll();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
