package com.mkmd.communication.waitNotify1.test;

/**
 * 方法wait()的作用是使当前执行代码的线程进行等待，wait()方法是Object类的方法，该方法是用来将当前线程置入“预执行队列”中，
 * 并且在wait()所在的代码行处停止执行，直到接到通知或被中断为止。 在调用wait()之前，线程必须获得该对象的对象级别锁。
 * 
 * 方法notify()也要在同步方法或同步块中调用，即在调用前，线程也必须获得该对象的对象级别锁。
 * 该方法用来通知那些可能等待该对象的对象锁的其他线程，如果有多个线程等待，则由线程规划器随机挑选出其中一个
 * 呈wait状态的线程，对其发出通知notify，并使它等待获取该对象的对象锁。
 * 需要说明的是，在执行notify()方法后，当前线程不会马上那个释放该对象，呈wait状态的线程也不能马上获取该对象，
 * 要等到执行notify()方法的线程将程序执行完，即退出synchronized代码块后，当前线程才会释放锁， 而呈wait状态所在线程才可以获取对象锁。
 * 
 * wait使线程停止运行，而notify是停止的线程继续运行
 * 
 * wait()方法可以使调用该方法的线程释放共享资源锁，然后从运行状态退出，进入等待队列，知道被再次唤醒。
 * notify()方法可以随机唤醒等待队列中等待同一共享资源的“一个”线程，并使该线程退出等待队列，进入可运行状态，也就是notify()方法仅通知“一个”线程
 * notifyAll()方法可以使所有正在等待队列中等待同一资源的“全部”线程从等待状态退出，进入可运行状态
 * 
 * 每个锁对象都有两个队列，一个是就绪队列，一个是阻塞队列。一个线程被唤醒后，才会进入就绪队列，等待CPU的调度；
 * 反之，一个线程被wait后，就会进入阻塞队列，等待下一次被召唤。
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		try {
			Object lock = new Object();
			ThreadA a = new ThreadA(lock);
			a.start();
			Thread.sleep(50);
			ThreadB b = new ThreadB(lock);
			b.start();

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
