package com.mkmd.communication.waitNotify3.test;

/**
 * 如果通知过早，则会打乱程序正常的运行逻辑，
 * 在使用wait/notify模式时，还需要注意另外一种情况，就是wait等待的天剑发生了变化，也容易造成程序逻辑的混乱
 * 
 * @author mahd
 *
 */
public class MyRun1 {
	static private Object lock = new Object();
	static private Runnable runnable1 = new Runnable() {

		@Override
		public void run() {
			try {
				synchronized (lock) {
					System.out.println("wait bengin time=" + System.currentTimeMillis());
					lock.wait();
					System.out.println("wait    end time=" + System.currentTimeMillis());
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	};
	static private Runnable runnable2 = new Runnable() {

		@Override
		public void run() {
			synchronized (lock) {
				System.out.println("notify bengin time=" + System.currentTimeMillis());
				lock.notify();
				System.out.println("notify    end time=" + System.currentTimeMillis());
			}
		}
	};

	public static void main(String[] args) throws InterruptedException {
		// 正常调用
		// MyRun1 my = new MyRun1();
		// Thread a = new Thread(my.runnable1);
		// a.start();
		// Thread b = new Thread(my.runnable2);
		// b.start();

		// 永远不会被通知的情况

		MyRun1 my = new MyRun1();
		Thread b = new Thread(my.runnable2);
		b.start();
		Thread.sleep(100);
		Thread a = new Thread(my.runnable1);
		a.start();

	}
}
