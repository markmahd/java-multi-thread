package com.mkmd.communication.join2.test;

public class ThreadB extends Thread {

	@Override
	public void run() {
		try {
			ThreadA t1 = new ThreadA();
			t1.start();
			t1.join();
			System.out.println("线程runnable2在run end打印了");
		} catch (InterruptedException e) {
			System.out.println("线程runnable2在catch打印了");
			e.printStackTrace();
		}
	}

}
