package com.mkmd.communication.join2.test;

/**
 * 在join过程中，如果当前线程对象被中断，则当前线程出现异常
 * 
 * @author mahd
 *
 */
public class Main {
	public static void main(String[] args) throws InterruptedException {
		ThreadB threadB = new ThreadB();
		threadB.start();
		Thread.sleep(500);

		ThreadC threadC = new ThreadC(threadB);
		threadC.start();

	}
}