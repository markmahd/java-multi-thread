package com.mkmd.communication.join2.test;

public class ThreadA extends Thread {

	@Override
	public void run() {
		for (int i = 0; i < Integer.MAX_VALUE; i++) {
			String nerString = new String();
			Math.random();

		}

	}

}
