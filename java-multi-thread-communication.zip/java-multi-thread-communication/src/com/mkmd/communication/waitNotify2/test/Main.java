package com.mkmd.communication.waitNotify2.test;
/**
 * 当线程呈wait状态时，调用线程对象的interrupt()方法会出现InterruptedException异常
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		try {
			Object lock = new Object();
			ThreadA a = new ThreadA(lock);
			a.start();
			Thread.sleep(5000);
			a.interrupt();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
