package com.mkmd.concurrent.syncSentence09.test;

public class ThreadA1 extends Thread {
	private Service1 service;
	private Myobject1 object;
	public ThreadA1(Service1 service, Myobject1 object) {
		super();
		this.service = service;
		this.object = object;
	}
	@Override
	public void run() {
		super.run();
		service.testMethod1(object);
	}
	

}
