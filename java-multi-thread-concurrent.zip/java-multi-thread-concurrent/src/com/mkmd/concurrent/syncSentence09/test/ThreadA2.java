package com.mkmd.concurrent.syncSentence09.test;

public class ThreadA2 extends Thread {
	private Service2 service;
	private Myobject2 object;

	public ThreadA2(Service2 service, Myobject2 object) {
		super();
		this.service = service;
		this.object = object;
	}

	@Override
	public void run() {
		super.run();
		service.testMethod1(object);
	}

}
