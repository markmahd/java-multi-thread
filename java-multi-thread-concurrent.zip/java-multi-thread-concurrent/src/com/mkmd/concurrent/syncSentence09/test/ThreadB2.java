package com.mkmd.concurrent.syncSentence09.test;

public class ThreadB2 extends Thread {
	private Service2 service;
	private Myobject2 object;

	public ThreadB2(Service2 service, Myobject2 object) {
		super();
		this.service = service;
		this.object = object;
	}

	@Override
	public void run() {
		super.run();
		object.speedPrintString();
	}

}
