package com.mkmd.concurrent.syncSentence09.test;

/**
 * 当其他线程执行x对象中的synchronized同步方法时呈现同步效果
 * 
 * @author mahd
 *
 */
public class Main2 {

	public static void main(String[] args) throws InterruptedException {
		Service2 service = new Service2();
		Myobject2 object = new Myobject2();
		ThreadA2 ta1 = new ThreadA2(service, object);
		ta1.setName("a");
		ta1.start();
		Thread.sleep(100);
		ThreadB2 tb1 = new ThreadB2(service, object);
		tb1.setName("b");
		tb1.start();

	}

}
