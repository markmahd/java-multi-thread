package com.mkmd.concurrent.syncSentence09.test;

public class Service2 {
	public void testMethod1(Myobject2 object) {
		synchronized (object) {
			try {
				System.out.println("testMethid1____getLock time=" + System.currentTimeMillis() + " run ThreadName="
						+ Thread.currentThread().getName());
				Thread.sleep(5000);
				System.out.println("testMethid1releaseLock time=" + System.currentTimeMillis() + " run ThreadName="
						+ Thread.currentThread().getName());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
