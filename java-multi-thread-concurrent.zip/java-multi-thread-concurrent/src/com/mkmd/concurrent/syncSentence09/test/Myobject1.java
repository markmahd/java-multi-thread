package com.mkmd.concurrent.syncSentence09.test;

public class Myobject1 {

}
