package com.mkmd.concurrent.syncSentence09.test;

/**
 * 当多个线程同时执行synchronized（x）{}同步代码块时呈现同步效果
 * 
 * @author mahd
 *
 */
public class Main1 {

	public static void main(String[] args) {
		// Service1 service = new Service1();
		// Myobject1 object = new Myobject1();
		// ThreadA1 ta1 = new ThreadA1(service, object);
		// ta1.setName("a");
		// ta1.start();
		// ThreadB1 tb1 = new ThreadB1(service, object);
		// tb1.setName("b");
		// tb1.start();

		Service1 service = new Service1();
		Myobject1 object1 = new Myobject1();
		Myobject1 object2 = new Myobject1();
		ThreadA1 ta1 = new ThreadA1(service, object1);
		ta1.setName("a");
		ta1.start();
		ThreadB1 tb1 = new ThreadB1(service, object2);
		tb1.setName("b");
		tb1.start();

	}

}
