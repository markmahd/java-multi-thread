package com.mkmd.concurrent.syncSentence09.test;

public class Service1 {
	public void testMethod1(Myobject1 object) {
		synchronized (object) {
			try {
				System.out.println("testMethid1____getLock time=" + System.currentTimeMillis() + " run ThreadName="
						+ Thread.currentThread().getName());
				Thread.sleep(2000);
				System.out.println("testMethid1releaseLock time=" + System.currentTimeMillis() + " run ThreadName="
						+ Thread.currentThread().getName());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
