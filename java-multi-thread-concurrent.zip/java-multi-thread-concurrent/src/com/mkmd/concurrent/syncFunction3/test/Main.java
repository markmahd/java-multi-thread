package com.mkmd.concurrent.syncFunction3.test;

/**
 * 调用用关键字synchronized声明的方法一定是排队运行的，另外需要牢牢记住“共享”这两个字，只有共享资源的书写访问才需要同步化。
 * 如果不是共享资源，根本没必要同步
 * 
 * 1、A线程现持有object对象的Lock锁，B线程可以以异步的方式调用object对象中的非synchronized类型的方法
 * 2、A线程先持有object对象的Lock锁，B线程如果在这是调用object对象中的synchronized类型的方法则需要等待，也就是同步
 * 
 * @author mahd
 *
 */
public class Main {
	public static void main(String[] args) {
		MyObject numRef = new MyObject();
		ThreadA tha = new ThreadA(numRef);
		tha.setName("A");

		ThreadB thb = new ThreadB(numRef);
		thb.setName("B");

		tha.start();
		thb.start();
	}
}
