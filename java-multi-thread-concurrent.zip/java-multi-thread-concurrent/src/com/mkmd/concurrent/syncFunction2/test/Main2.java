package com.mkmd.concurrent.syncFunction2.test;

/**
 * 关键字synchronized取得的锁对视对象锁，而不是把一段代码或方法（函数）当作锁，但如果多个线程访问多个对象，则JVM会创建多个锁。
 * 同步的单词是synchronized，异步的单词为asynchronized
 * 
 * @author mahd
 *
 */
public class Main2 {
	public static void main(String[] args) {
		HasSelfPrivateNum numRef1 = new HasSelfPrivateNum();
		HasSelfPrivateNum numRef2 = new HasSelfPrivateNum();
		ThreadA tha = new ThreadA(numRef1);
		tha.start();
		ThreadB thb = new ThreadB(numRef2);
		thb.start();
	}
}
