package com.mkmd.concurrent.syncFunction2.test;

/**
 * 如果两个线程访问同一个对象中的同步方法时一定是线程安全的
 * 
 * @author mahd
 *
 */
public class Main {
	public static void main(String[] args) {
		HasSelfPrivateNum numRef = new HasSelfPrivateNum();
		ThreadA tha = new ThreadA(numRef);
		tha.start();
		ThreadB thb = new ThreadB(numRef);
		thb.start();
	}
}
