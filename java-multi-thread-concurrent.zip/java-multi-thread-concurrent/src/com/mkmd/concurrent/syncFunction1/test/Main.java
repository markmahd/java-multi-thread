package com.mkmd.concurrent.syncFunction1.test;

/**
 * 非线程安全问题存在于实例变量中，如果是方法内部的私有变量，则不存在非线程安全问题，所得结果也就是线程安全的了。 这是方法内部的变量是私有的特性造成的
 * 
 * @author mahd
 *
 */
public class Main {
	public static void main(String[] args) {
		HasSelfPrivateNum numRef = new HasSelfPrivateNum();
		ThreadA tha = new ThreadA(numRef);
		tha.start();
		ThreadB thb = new ThreadB(numRef);
		thb.start();
	}
}
