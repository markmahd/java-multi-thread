package com.mkmd.concurrent.syncSentence04.test;

/**
 * 一半异步，一半同步：不在synchronized块中的就是异步执行，在synchronized块中就是同步执行
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		Task task = new Task();
		MyThread1 thread1 = new MyThread1(task);
		thread1.start();
		MyThread2 thread2 = new MyThread2(task);
		thread2.start();
	}

}
