package com.mkmd.concurrent.syncFunction6.test;

/***
 * 当一个线程执行的代码出现异常时，器所持有的锁会自动释放
 * 
 * @author mahd
 *
 */
public class Main {
	public static void main(String[] args) {
		try {
			Service service = new Service();
			ThreadA tha = new ThreadA(service);
			tha.setName("a");
			tha.start();

			Thread.sleep(500);

			ThreadA thb = new ThreadA(service);
			thb.setName("b");
			thb.start();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
