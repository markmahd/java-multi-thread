package com.mkmd.concurrent.syncSentence14.test;

/**
 * 有多个线程同时持有锁对象，如果同时持有相同的锁对象，则线程之间是同步的，如果分别获得锁对象，线程之间就是异步的
 * 只要对象不变，即使是对象属性被改变，运行的结果还是同步的
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) throws InterruptedException {
		MyService service = new MyService();
		ThreadA tha = new ThreadA(service);
		tha.setName("A");
		ThreadB thb = new ThreadB(service);
		thb.setName("B");
		tha.start();
		// Thread.sleep(50);
		thb.start();

	}

}
