package com.mkmd.concurrent.syncSentence08.test;

/**
 * 使用synchronized（非this）同步代码块格式也可以解决脏读问题
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) throws InterruptedException {
		MyOneList list = new MyOneList();
		MyThread1 th1 = new MyThread1(list);
		th1.setName("A");
		th1.start();
		MyThread2 th2 = new MyThread2(list);
		th2.setName("B");
		th2.start();
		Thread.sleep(6000);
		System.out.println("listSize=" + list.getSize());
	}

}
