package com.mkmd.concurrent.syncFunction5.test;

public class MyThread extends Thread {
	@Override
	public void run() {
		Service service = new Service();
		service.service1();
		System.out.println("************************");
		Son son = new Son();
		son.operateISubMethod();
	}

}
