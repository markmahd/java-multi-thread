package com.mkmd.concurrent.syncFunction5.test;

/**
 * 关键字synchronized拥有锁重入的功能，也就是在使用synchronized时，当一个线程得到一个对象锁后，再次请求该对象锁时是可以再次得到该对象的锁的。
 * 在一个synchronized方法/块的内部调用本类的其他synchronized方法/块时，是永远可以得到锁的。
 * 
 * 当存在父子类继承关系时，子类完全可以通过“可重入锁”调用父类的同步方法
 * 
 * @author mahd
 *
 */
public class Main {
	public static void main(String[] args) {
		MyThread t = new MyThread();
		t.start();
	}
}
