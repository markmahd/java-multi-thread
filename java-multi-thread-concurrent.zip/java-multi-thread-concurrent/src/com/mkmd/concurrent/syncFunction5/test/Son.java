package com.mkmd.concurrent.syncFunction5.test;

public class Son extends Father {
	synchronized public void operateISubMethod() {
		try {
			while (i > 0) {
				i--;
				System.out.println("son print i=" + i);

				Thread.sleep(100);
				this.operateIMainMethod();

			}

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
