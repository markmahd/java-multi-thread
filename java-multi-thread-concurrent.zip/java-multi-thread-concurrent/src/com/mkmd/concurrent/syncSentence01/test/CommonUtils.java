package com.mkmd.concurrent.syncSentence01.test;

public class CommonUtils {
	public static long beginTime1;
	public static long endTime1;
	public static long beginTime2;
	public static long endTime2;

}
