package com.mkmd.concurrent.syncSentence05.test;

/**
 * 在使用同步synchronized (this)代码块时需要注意的是，当一个线程访问object的一个synchronized(this)同步代码块时，
 * 其他线程对同一个object中所有其他synchronized(this)同步代码块的访问江北阻塞，
 * 这说明synchronized使用的“对象监视器”是一个
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		ObjectService object = new ObjectService();
		ThreadA thread1 = new ThreadA(object);
		thread1.setName("a");
		thread1.start();
		ThreadB thread2 = new ThreadB(object);
		thread2.setName("b");
		thread2.start();
	}

}
