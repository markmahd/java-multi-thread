package com.mkmd.concurrent.volatile3.test;

/**
 * 除了在i++操作时使用synchronized关键字实现同步外，还可以使用AtomicInteger原子类进行实现
 * 但原子类在具有逻辑性的情况下输出结果也具有随机性
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		AddCountThread addCountThread = new AddCountThread();
		Thread t1 = new Thread(addCountThread);
		t1.start();
		Thread t2 = new Thread(addCountThread);
		t2.start();
		Thread t3 = new Thread(addCountThread);
		t3.start();
		Thread t4 = new Thread(addCountThread);
		t4.start();
		Thread t5 = new Thread(addCountThread);
		t5.start();

	}

}
