package com.mkmd.concurrent.volatile1.test;

/**
 * 同步死循环，在-server服务器模式64bit的JVM上，可以用volatile
 * volatile的作用是使变量在多个线程间可见，即强制从公共堆栈中去的变量的值，而不是从线程私有的数据栈中取得变量值
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		// PrintString printString = new PrintString();
		// printString.printStringMethod();
		PrintString2 printString = new PrintString2();
		new Thread(printString).start();
		System.out.println("我要停止她！ stopThread=" + Thread.currentThread().getName());
		printString.setContinuePrint(false);

	}

}
