package com.mkmd.concurrent.syncSentence11.test;

/**
 * 同步方法容易造成死循环，可以使用同步块来解决
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		Service service = new Service();
		ThreadA a = new ThreadA(service);
		a.start();
		ThreadB b = new ThreadB(service);
		b.start();

	}

}
