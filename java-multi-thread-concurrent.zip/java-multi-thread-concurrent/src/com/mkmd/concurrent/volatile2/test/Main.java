package com.mkmd.concurrent.volatile2.test;

/**
 * 关键字volatile虽然增加类实例变量在线程之间的可见性，但是他不具备同步性，那么也不具备原子性
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		MyThread[] mythreadArray = new MyThread[100];
		for (int i = 0; i < 100; i++) {
			mythreadArray[i] = new MyThread();

		}
		for (int i = 0; i < 100; i++) {
			mythreadArray[i].start();

		}

	}

}
