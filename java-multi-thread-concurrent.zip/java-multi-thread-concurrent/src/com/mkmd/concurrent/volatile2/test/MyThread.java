package com.mkmd.concurrent.volatile2.test;

public class MyThread extends Thread {
	volatile public static int count = 0;

	/**
	 * 注意一定要添加static关键字 这样synchronized与static锁的内容就是MyThread.class类了 也就达到同步的目的了
	 * 
	 */
	// public static void addCount() {
	synchronized public static void addCount() {
		for (int i = 0; i < 100; i++) {
			count++;

		}
		System.out.println("count=" + count);
	}

	@Override
	public void run() {
		addCount();
	}

}
