package com.mkmd.concurrent.syncFunction7.test;

public class ThreadA extends Thread {
	private Son son;

	public ThreadA(Son son) {
		super();
		this.son = son;
	}

	@Override
	public void run() {
		son.serviceMethod();
	}

}
