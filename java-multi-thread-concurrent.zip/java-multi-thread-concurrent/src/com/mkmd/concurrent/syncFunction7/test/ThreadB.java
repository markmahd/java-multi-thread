package com.mkmd.concurrent.syncFunction7.test;

public class ThreadB extends Thread {
	private Son son;

	public ThreadB(Son son) {
		super();
		this.son = son;
	}

	@Override
	public void run() {
		son.serviceMethod();
	}

}
