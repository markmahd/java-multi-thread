package com.mkmd.concurrent.syncFunction7.test;

/**
 * 同步不可以继承
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		Son son = new Son();
		ThreadA a = new ThreadA(son);
		a.setName("A");
		a.start();
		ThreadB b = new ThreadB(son);
		b.setName("B");
		b.start();

	}

}
