package com.mkmd.concurrent.syncSentence12.test;

/**
 * Java线程死锁是一个经典的多线程问题，因为不同的线程都在等待根本不可能被释放的锁，从未导致所有的任务无法继续完成
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		try {
			DealThread t1 = new DealThread();
			t1.setFlag("a");
			Thread th1 = new Thread(t1);
			th1.start();
			Thread.sleep(100);
			t1.setFlag("b");
			Thread th2 = new Thread(t1);
			th2.start();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
