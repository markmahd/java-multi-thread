package com.mkmd.concurrent.syncSentence12.test;

public class DealThread implements Runnable {
	public String username;
	public Object lovk1 = new Object();
	public Object lovk2 = new Object();

	public void setFlag(String username) {
		this.username = username;
	}

	@Override
	public void run() {
		if (username.equals("a")) {
			synchronized (lovk1) {

				try {
					System.out.println("username=" + username);
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				synchronized (lovk2) {
					System.out.println("按lovk1-->lovk2代码顺序执行了");
				}
			}
		}
		if (username.equals("b")) {
			synchronized (lovk2) {

				try {
					System.out.println("username=" + username);
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				synchronized (lovk1) {
					System.out.println("按lovk2-->lovk1代码顺序执行了");
				}
			}
		}

	}

}
