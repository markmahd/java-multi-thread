package com.mkmd.concurrent.syncSentence13.test;

import com.mkmd.concurrent.syncSentence13.test.OutClass.InnerClass1;
import com.mkmd.concurrent.syncSentence13.test.OutClass.InnerClass2;

/**
 * 在内置类中有两个同步方法，但是使用不同的锁，打印结果也是异步的
 * 同步代码块synchronized(x)对对象x上锁后，其他线程只能以同步的方式调用对象x中的静态同步方法
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		final InnerClass1 in1 = new InnerClass1();
		final InnerClass2 in2 = new InnerClass2();

		Thread t1 = new Thread(new Runnable() {

			public void run() {
				in1.method1(in2);

			}
		});
		Thread t2 = new Thread(new Runnable() {

			public void run() {
				in1.method2();

			}
		});
		// //
		// //
		Thread t3 = new Thread(new Runnable() {

			public void run() {
				in2.method1();

			}
		});
		t1.start();
		t2.start();
		t3.start();

	}

}
