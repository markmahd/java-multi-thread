package com.mkmd.concurrent.syncSentence07.test;

/**
 * 锁非this对象具有一定的优点：如果在一个类中有多个synchronized方法，这是虽然能实现同步，但会受到阻塞，所以影响效率；
 * 但如果使用同步代码块锁非this对象，则synchronized（非this）代码块中的程序与同步方法时异步的，不予其他所this同步方法争抢this锁，则大大的提高效率
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		Service object = new Service();
		ThreadA thread1 = new ThreadA(object);
		thread1.setName("A");
		thread1.start();
		ThreadB thread2 = new ThreadB(object);
		thread2.setName("B");
		thread2.start();
	}

}
