package com.mkmd.concurrent.syncSentence10.test;

public class ThreadB extends Thread {

	@Override
	public void run() {
		Service.printB();
	}

}
