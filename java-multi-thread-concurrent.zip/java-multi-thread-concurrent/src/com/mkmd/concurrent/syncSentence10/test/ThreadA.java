package com.mkmd.concurrent.syncSentence10.test;

public class ThreadA extends Thread {

	@Override
	public void run() {
		Service.printA();
	}

}
