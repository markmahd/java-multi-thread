package com.mkmd.concurrent.syncSentence10.test;

/**
 * synchronized关键字加到static静态方法上是个Class类上锁，而synchronized关键字加到非static静态方法上是个对象上锁
 * 
 * 在大多数情况下同步synchronized代码块都不使用String（常量池）作为锁对象，而改用其他，例如new
 * String（）实例化一个Object对象
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		ThreadA th1 = new ThreadA();
		th1.setName("A");
		th1.start();
		ThreadB th2 = new ThreadB();
		th2.setName("B");
		th2.start();

	}

}
