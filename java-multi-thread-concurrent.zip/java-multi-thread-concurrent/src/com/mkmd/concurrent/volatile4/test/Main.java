package com.mkmd.concurrent.volatile4.test;

/**
 * synchronized与volatile比较
 * 1、关键字volatile是线程同步的轻量级实现，所以volatile性能肯定比synchronized要好，
 * 并且volatile只能修饰变量，二synchronized可以修饰方法，以及代码块。随着jdk新版本的发布，
 * synchronized关键字在执行效率上得到很大的提升，在开发中使用synchronized关键字的比率还是比较大的。
 * 2、多线程访问volatile不会发生阻塞，而synchronized会出现阻塞
 * 3、volatile能保证数据的可见性，但不能保证原子性；而synchronized可以保证原子性，
 * 也可以间接保证可见性，因为他会将私有内存和公共内存中的数据同步。
 * 4、关键字volatile解决的是变量在多个线程之间的可见性，而synchronized关键字介解决的事多个线程之间访问资源的同步性。
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		try {
			Service service = new Service();
			ThreadA tha = new ThreadA(service);
			tha.start();
			Thread.sleep(1000);
			ThreadB thb = new ThreadB(service);
			thb.start();
			System.out.println("已经发起停止的命令了");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
