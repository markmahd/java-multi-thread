package com.mkmd.concurrent.syncFunction4.test;

/**
 * 发生脏读的情况实在读取实例变量时，此值已经被其他线程更改过。 脏读一定会出现操作实例变量的情况下，这就是不同线程“争抢”实例变量的结果
 * 
 * @author mahd
 *
 */
public class Main {
	public static void main(String[] args) {
		try {
			PublicVar numRef = new PublicVar();
			ThreadA tha = new ThreadA(numRef);
			tha.start();

			Thread.sleep(200);// 打印结果受此值大小的影响
			numRef.getValue();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
