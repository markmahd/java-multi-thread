package com.mkmd.concurrent.syncSentence02.test;

public class ThreadB extends Thread {
	private ObjectService object;

	public ThreadB(ObjectService object) {
		super();
		this.object = object;
	}

	@Override
	public void run() {
		super.run();
		object.serviceMethod();
	}

}
