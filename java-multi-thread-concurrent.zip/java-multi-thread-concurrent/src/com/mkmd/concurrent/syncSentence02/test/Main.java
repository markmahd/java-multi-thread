package com.mkmd.concurrent.syncSentence02.test;

/**
 * 当两个并发线程访问同一个对象的synchronized (this)同步块代码时，一段时间内只能有一个线程被执行，
 * 另一个线程必须等待当前线程执行完这个代码块以后才只能执行该代码块
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		ObjectService task = new ObjectService();
		ThreadA thread1 = new ThreadA(task);
		thread1.setName("a");
		thread1.start();
		ThreadB thread2 = new ThreadB(task);
		thread2.setName("b");
		thread2.start();
	}

}
