package com.mkmd.additional.exception2.test;

/**
 * 线程组运行报异常:其中一个运行异常，其他不影响
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		ThreadGroup group = new ThreadGroup("myGroup");
		MyThread[] thArray = new MyThread[10];
		for (int i = 0; i < thArray.length; i++) {

			thArray[i] = new MyThread(group, "线程" + (i + 1), "1");
			thArray[i].start();
		}
		MyThread newT = new MyThread(group, "报错线程", "a");
		newT.start();
	}

}
