package com.mkmd.additional.exception2.test;

public class MyThread2 extends Thread {
	private String num;

	public MyThread2(ThreadGroup group, String name, String num) {
		super(group, name);
		this.num = num;
	}

	@Override
	public void run() {
		int numInt = Integer.parseInt(num);
		while (this.isInterrupted() == false) {
			System.out.println("四玄幻中：" + Thread.currentThread().getName());
		}
	}

}
