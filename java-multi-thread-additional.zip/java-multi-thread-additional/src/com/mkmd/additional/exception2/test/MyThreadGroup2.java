package com.mkmd.additional.exception2.test;

public class MyThreadGroup2 extends ThreadGroup {

	public MyThreadGroup2(String name) {
		super(name);
	}

	@Override
	public void uncaughtException(Thread t, Throwable e) {
		super.uncaughtException(t, e);
		this.interrupt();
	}

}
