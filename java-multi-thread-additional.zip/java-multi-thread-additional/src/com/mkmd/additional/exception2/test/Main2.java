package com.mkmd.additional.exception2.test;

/**
 * 线程组运行报异常:其中一个运行异常，其他也停止
 * 
 * @author mahd
 *
 */
public class Main2 {

	public static void main(String[] args) {
		MyThreadGroup2 group = new MyThreadGroup2("myGroup");
		MyThread2[] thArray = new MyThread2[10];
		for (int i = 0; i < thArray.length; i++) {

			thArray[i] = new MyThread2(group, "线程" + (i + 1), "1");
			thArray[i].start();
		}
		MyThread2 newT = new MyThread2(group, "报错线程", "a");
		newT.start();
	}

}
