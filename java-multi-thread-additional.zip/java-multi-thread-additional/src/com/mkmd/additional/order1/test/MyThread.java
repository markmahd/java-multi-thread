package com.mkmd.additional.order1.test;

public class MyThread extends Thread {
	private Object lock;
	private String showchar;
	private int showNumPosition;
	private int printCount = 0;// 统计打印了几个字母
	volatile private static int addNumber = 1;

	public MyThread(Object object, String showchar, int showNumPosition) {
		super();
		this.lock = object;
		this.showchar = showchar;
		this.showNumPosition = showNumPosition;
	}

	@Override
	public void run() {
		try {
			synchronized (lock) {
				while (true) {
					if (addNumber % 3 == showNumPosition) {
						System.out.println("ThreadName=" + Thread.currentThread().getName() + " runCount=" + addNumber
								+ " " + showchar);
						lock.notifyAll();
						addNumber++;
						printCount++;
						if (printCount == 3) {
							break;
						}
					} else {
						lock.wait();
					}
				}

			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
