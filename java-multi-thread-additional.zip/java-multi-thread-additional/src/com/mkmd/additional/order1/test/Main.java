package com.mkmd.additional.order1.test;

/**
 * 使线程具有有序性
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		Object lock = new Object();
		MyThread a = new MyThread(lock, "A", 1);
		MyThread b = new MyThread(lock, "B", 2);
		MyThread c = new MyThread(lock, "C", 0);
		a.start();
		b.start();
		c.start();
	}

}
