package com.mkmd.additional.exception1.test;

import java.lang.Thread.UncaughtExceptionHandler;

/**
 * 线程运行报异常
 * 
 * @author mahd
 *
 */
public class Main3 {

	public static void main(String[] args) {

		// 为指定线程类的所有类对象设置默认的异常处理器
		MyThread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler() {

			@Override
			public void uncaughtException(Thread t1, Throwable e) {
				System.out.println("线程：" + t1.getName() + "出现异常：");
				e.printStackTrace();

			}
		});
		MyThread t = new MyThread();
		t.setName("线程t");
		t.start();
		MyThread t2 = new MyThread();
		t2.setName("线程2");
		t2.start();

	}

}
