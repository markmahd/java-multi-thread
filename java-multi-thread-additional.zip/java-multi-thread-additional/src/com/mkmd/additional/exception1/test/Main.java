package com.mkmd.additional.exception1.test;

/**
 * 线程运行报异常
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		MyThread t = new MyThread();
		t.start();
	}

}
