package com.mkmd.additional.exception1.test;

import java.lang.Thread.UncaughtExceptionHandler;

/**
 * 线程运行报异常
 * 
 * @author mahd
 *
 */
public class Main2 {

	public static void main(String[] args) {
		MyThread t = new MyThread();
		t.setName("线程t");
		// 对指定线程对象设置异常处理器
		t.setUncaughtExceptionHandler(new UncaughtExceptionHandler() {

			@Override
			public void uncaughtException(Thread t1, Throwable e) {
				System.out.println("线程：" + t1.getName() + "出现异常：");
				e.printStackTrace();

			}
		});
		t.start();
		MyThread t2 = new MyThread();
		t2.setName("线程2");
		t2.start();

	}

}
