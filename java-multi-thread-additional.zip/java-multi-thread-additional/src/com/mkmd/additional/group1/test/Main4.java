package com.mkmd.additional.group1.test;

/**
 * 4、获取根线程组： JVM的根线程组就是system，再取父线程组出现空异常
 * 
 * @author mahd
 *
 */
public class Main4 {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("A出线程" + Thread.currentThread().getName() + " 所属线程组名为："
				+ Thread.currentThread().getThreadGroup().getName());
		System.out.println("父线程组名称：" + Thread.currentThread().getThreadGroup().getParent().getName());
		System.out.println("父线程组的父线程组名称：" + Thread.currentThread().getThreadGroup().getParent().getParent().getName());

	}

}
