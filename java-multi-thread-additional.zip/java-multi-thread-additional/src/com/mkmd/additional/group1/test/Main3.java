package com.mkmd.additional.group1.test;

/**
 * 3、线程组自动归属就是自动归到当前线程组中
 * 
 * @author mahd
 *
 */
public class Main3 {

	public static void main(String[] args) throws InterruptedException {
		// 方法activeGroupCount取得当前线程组对象中的子线程组的数量
		// 方法enumerate的作用是将线程组中的子线程组以复制的形式拷贝到ThreadGroup[]数组对象中
		System.out.println("A出线程" + Thread.currentThread().getName() + " 所属线程组名为："
				+ Thread.currentThread().getThreadGroup().getName() + " 中有线程组数量为："
				+ Thread.currentThread().getThreadGroup().activeGroupCount());
		ThreadGroup group = new ThreadGroup("newG");
		System.out.println("B出线程" + Thread.currentThread().getName() + " 所属线程组名为："
				+ Thread.currentThread().getThreadGroup().getName() + " 中有线程组数量为："
				+ Thread.currentThread().getThreadGroup().activeGroupCount());

		ThreadGroup[] listGroup = new ThreadGroup[Thread.currentThread().getThreadGroup().activeGroupCount()];
		Thread.currentThread().getThreadGroup().enumerate(listGroup);
		for (int i = 0; i < listGroup.length; i++) {

			System.out.println(i + "线程组名称为：" + listGroup[i].getName());
		}
	}

}
