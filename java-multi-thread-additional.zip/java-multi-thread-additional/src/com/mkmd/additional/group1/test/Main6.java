package com.mkmd.additional.group1.test;

/**
 * 6、组内线程批量停止
 * 
 * @author mahd
 *
 */
public class Main6 {

	public static void main(String[] args) {
		try {
			ThreadGroup newGroup = new ThreadGroup("myGroup");
			for (int i = 0; i < 5; i++) {
				MyThread6 myThread6 = new MyThread6(newGroup, "线程" + (i + 1));
				myThread6.start();
			}
			Thread.sleep(5000);
			newGroup.interrupt();
			System.out.println("调用了interrupt方法");
		} catch (InterruptedException e) {
			System.out.println("停止了");
			e.printStackTrace();
		}

	}

}
