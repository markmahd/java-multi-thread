package com.mkmd.additional.group1.test;

/**
 * 线程组中可以有线程对象，也可以有线程组，组中还可以有线程 线程组的作用是可以批量的管理线程或线程组对象，有效的对线程或线程组对象组织
 * 
 * 1、一级关联就是父对象中有子对象，但并不能创建子孙对象，可以对零散的线程进行有效的组织和规划
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) throws InterruptedException {
		ThreadA aRunnable = new ThreadA();
		ThreadB bRunnable = new ThreadB();
		ThreadGroup threadGroup = new ThreadGroup("first ThreadGroup");
		Thread ta = new Thread(threadGroup, aRunnable);
		Thread tb = new Thread(threadGroup, bRunnable);
		ta.start();
		tb.start();
		System.out.println("活动的线程数为：" + threadGroup.activeCount());
		System.out.println("线程组的名称为：" + threadGroup.getName());
	}

}
