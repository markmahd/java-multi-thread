package com.mkmd.additional.group1.test;

/**
 * 2、多级关联就是父对象中有子对象，子对象中在创建子对象，也就是出现子孙对象的效果
 * 
 * @author mahd
 *
 */
public class Main2 {

	public static void main(String[] args) throws InterruptedException {
		// 在main组中添加一个线程组A，然后在这个组A中添加线程对象Z
		// 方法activeGroupCount和activeCount的值不是固定的
		// 是系统环境的一个快照
		ThreadGroup mainGroup = Thread.currentThread().getThreadGroup();
		ThreadGroup group = new ThreadGroup(mainGroup, "A");
		Runnable runnable = new Runnable() {

			@Override
			public void run() {
				try {
					System.out.println("runMethod!");
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			}
		};
		Thread newThread = new Thread(group, runnable);
		newThread.setName("Z");
		newThread.start();

		ThreadGroup[] listGroup = new ThreadGroup[Thread.currentThread().getThreadGroup().activeGroupCount()];
		Thread.currentThread().getThreadGroup().enumerate(listGroup);
		System.out.println("main线程中有多少个子线程组：" + listGroup.length + " 名字为：" + listGroup[0].getName());
		Thread[] listThread = new Thread[listGroup[0].activeCount()];
		listGroup[0].enumerate(listThread);
		System.out.println(listThread[0].getName());
	}

}
