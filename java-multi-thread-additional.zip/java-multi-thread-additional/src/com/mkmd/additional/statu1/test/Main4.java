package com.mkmd.additional.statu1.test;

/**
 * 
 * WAITING:线程执行了Object.wait()方法后所处的状态
 * 
 * @author mahd
 *
 */
public class Main4 {

	public static void main(String[] args) throws InterruptedException {
		MyThread4 a = new MyThread4();
		a.start();
		Thread.sleep(1000);
		System.out.println("main方法中的状态：" + a.getState());
	}

}
