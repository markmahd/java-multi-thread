package com.mkmd.additional.statu1.test;

/**
 * 线程对象在不同的运行十七有不同的状态，状态信息就存在State枚举类中
 * 
 * NEW:线程实例化后还未执行start()方法时的状态
 * 
 * RUNNABLE:线程进入运行的状态
 * 
 * TERMINATED:线程被销毁时的状态
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) throws InterruptedException {
		MyThread myThread = new MyThread();
		System.out.println("main方法中的状态1：" + myThread.getState());
		Thread.sleep(1000);
		myThread.start();
		Thread.sleep(1000);
		System.out.println("main方法中的状态2：" + myThread.getState());

	}

}
