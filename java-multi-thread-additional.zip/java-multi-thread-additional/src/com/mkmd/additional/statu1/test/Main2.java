package com.mkmd.additional.statu1.test;

/**
 * 
 * TIMED_WAITING:代表线程执行Thread.sleep()方法，呈等待状态，等待时间到达，继续向下运行
 * 
 * @author mahd
 *
 */
public class Main2 {

	public static void main(String[] args) throws InterruptedException {
		MyThread2 myThread = new MyThread2();
		myThread.start();
		Thread.sleep(1000);
		System.out.println("main方法中的状态：" + myThread.getState());

	}

}
