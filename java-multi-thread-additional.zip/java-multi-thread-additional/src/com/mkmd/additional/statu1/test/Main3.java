package com.mkmd.additional.statu1.test;

/**
 * 
 * BLOCKED:出现在某一个线程在等待锁的时候
 * 
 * @author mahd
 *
 */
public class Main3 {

	public static void main(String[] args) throws InterruptedException {
		ThreadA a = new ThreadA();
		a.setName("a");
		a.start();
		Thread.sleep(100);
		ThreadB b = new ThreadB();
		b.setName("b");
		b.start();
		Thread.sleep(100);
		System.out.println("main方法中的状态：" + b.getState());
	}

}
