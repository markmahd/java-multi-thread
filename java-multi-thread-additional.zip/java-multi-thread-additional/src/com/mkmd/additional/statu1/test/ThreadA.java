package com.mkmd.additional.statu1.test;

public class ThreadA extends Thread {

	@Override
	public void run() {
		MyService.serviceMethod();
	}

}
