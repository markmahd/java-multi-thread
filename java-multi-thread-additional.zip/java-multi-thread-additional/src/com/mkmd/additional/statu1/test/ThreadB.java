package com.mkmd.additional.statu1.test;

public class ThreadB extends Thread {

	@Override
	public void run() {
		MyService.serviceMethod();
	}

}
