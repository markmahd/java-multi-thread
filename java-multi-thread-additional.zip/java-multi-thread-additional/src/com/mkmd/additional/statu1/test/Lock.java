package com.mkmd.additional.statu1.test;

public class Lock {
	public static final Byte lock = new Byte("0");

}
