package com.mkmd.additional.exception3.test;

public class MyThread extends Thread {
	private String num = "a";

	public MyThread() {
		super();
	}

	public MyThread(ThreadGroup group, String name) {
		super(group, name);
	}

	@Override
	public void run() {
		int numInt = Integer.parseInt(num);
		while (true) {
			System.out.println("在线程重打印：" + (numInt + 1));
		}
	}

}
