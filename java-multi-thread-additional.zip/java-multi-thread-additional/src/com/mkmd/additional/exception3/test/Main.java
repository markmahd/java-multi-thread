package com.mkmd.additional.exception3.test;

/**
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {
		MyThread newT = new MyThread();
		// 对象
		//newT.setUncaughtExceptionHandler(new ObjectUncaughtExceptionHandler());
		// 类
		newT.setDefaultUncaughtExceptionHandler(new StateUncaughtExceptionHandler());
		newT.start();
	}

}
