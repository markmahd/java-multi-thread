package com.mkmd.additional.exception3.test;

/**
 * 
 * @author mahd
 *
 */
public class Main2 {

	public static void main(String[] args) {
		MyThreadGroup group = new MyThreadGroup("myGroup");
		MyThread newT = new MyThread(group, "newThread");
		// 对象
		//newT.setUncaughtExceptionHandler(new ObjectUncaughtExceptionHandler());
		// 类
		//newT.setDefaultUncaughtExceptionHandler(new StateUncaughtExceptionHandler());
		newT.start();
	}

}
