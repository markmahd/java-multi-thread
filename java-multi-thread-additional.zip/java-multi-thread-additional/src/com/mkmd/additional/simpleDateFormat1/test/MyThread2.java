package com.mkmd.additional.simpleDateFormat1.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MyThread2 extends Thread {
	private SimpleDateFormat sdf;
	private String dateString;

	public MyThread2(SimpleDateFormat sdf, String dateString) {
		super();
		this.sdf = sdf;
		this.dateString = dateString;
	}

	@Override
	public void run() {
		try {
			Date dateRef = DateTools2.parse("yyyy-MM-dd", dateString);
			String newDateString = DateTools2.format("yyyy-MM-dd", dateRef).toString();
			if (!newDateString.equals(dateString)) {
				System.out.println(
						"ThreadName=" + this.getName() + "报错了 日期字符串：" + dateString + "转换成日期为：" + newDateString);
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}

	}

}
