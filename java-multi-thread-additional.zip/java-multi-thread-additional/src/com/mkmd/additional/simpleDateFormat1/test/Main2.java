package com.mkmd.additional.simpleDateFormat1.test;

import java.text.SimpleDateFormat;

/**
 * SimpleDateFormat解决方法1
 * 
 * @author mahd
 *
 */
public class Main2 {

	public static void main(String[] args) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String[] dataStringArray = new String[] { "2018-05-17", "2018-04-17", "2018-03-17", "2018-05-12", "2018-05-15",
				"2018-05-13", "2018-05-27", "2018-05-14", "2018-05-18", "2018-01-17" };
		MyThread2[] threadArray = new MyThread2[10];
		for (int i = 0; i < 10; i++) {
			threadArray[i] = new MyThread2(sdf, dataStringArray[i]);

		}
		for (int i = 0; i < 10; i++) {
			threadArray[i].start();
		}
	}

}
