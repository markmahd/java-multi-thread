package com.mkmd.additional.simpleDateFormat1.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTools2 {
	public static Date parse(String formatPattern, String dateString) throws ParseException {
		return new SimpleDateFormat(formatPattern).parse(dateString);

	}

	public static String format(String formatPattern, Date date) {
		return new SimpleDateFormat(formatPattern).format(date).toString();
	}

}
