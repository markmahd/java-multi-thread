package com.mkmd.timer.schedule1.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

/**
 * schedule(TimerTask task,Date firstTime,long
 * period):该方法的作用是在指定的日期之后，按指定的间隔周期性的无限循环的执行某一任务
 * 
 * @author mahd
 *
 */
public class Main2 {
	private static Timer timer = new Timer();// 运行后线程还在继续

	static public class MyTask extends TimerTask {

		@Override
		public void run() {
			System.out.println("运行了！时间为" + new Date());

		}

	}

	public static void main(String[] args) {

		// 1、计划时间晚于当前时间：在未来执行的效果
		// try {
		// MyTask myTask = new MyTask();
		// SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		// String dateString = "2018-05-16 10:04:00";
		// Date dateSdf = sdf.parse(dateString);
		// System.out.println("字符串时间：" + dateString + " 当前时间：" + new
		// Date().toLocaleString());
		// timer.schedule(myTask, dateSdf, 4000);
		// } catch (ParseException e) {
		// e.printStackTrace();
		// }

		// 2、计划时间早于当前时间：提前执行的效果，立即执行task任务
		try {
			MyTask myTask = new MyTask();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String dateString = "2018-05-16 10:04:00";
			Date dateSdf = sdf.parse(dateString);
			System.out.println("字符串时间：" + dateString + " 当前时间：" + new Date().toLocaleString());
			timer.schedule(myTask, dateSdf, 4000);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		// 3、多个TimerTask任务及延时测试
		// try {
		// MyTask myTask = new MyTask();
		// MyTask2 myTask2 = new MyTask2();
		// SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		// SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		// String dateString = "2018-05-16 09:53:30";
		// String dateString2 = "2018-05-16 09:53:40";
		// Date dateSdf = sdf.parse(dateString);
		// Date dateSdf2 = sdf2.parse(dateString2);
		// System.out.println("字符串1时间：" + dateString + " 当前时间：" + new
		// Date().toLocaleString());
		// System.out.println("字符串2时间：" + dateString2 + " 当前时间：" + new
		// Date().toLocaleString());
		// timer.schedule(myTask, dateSdf);
		// timer.schedule(myTask2, dateSdf2);
		// } catch (ParseException e) {
		// e.printStackTrace();
		// }
	}

}
