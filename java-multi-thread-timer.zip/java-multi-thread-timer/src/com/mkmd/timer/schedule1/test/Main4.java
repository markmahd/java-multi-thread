package com.mkmd.timer.schedule1.test;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

/**
 * schedule(TimerTask task,long delay,long period):该方法的作用是以执行该方法当前时间为参考时间，
 * 在此时间基础上延迟指定毫秒数，再以某一间隔时间无限次数的执行某一任务
 * 
 * @author mahd
 *
 */
public class Main4 {
	static public class MyTask extends TimerTask {

		@Override
		public void run() {
			System.out.println("运行了！时间为" + new Date());

		}

	}

	public static void main(String[] args) {

		MyTask myTask = new MyTask();
		Timer timer = new Timer();
		System.out.println(" 当前时间：" + new Date().toLocaleString());
		timer.schedule(myTask, 4000, 5000);

	}

}
