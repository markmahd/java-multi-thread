package com.mkmd.timer.schedule1.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

/**
 * schedule(TimerTask task,Date firstTime,long
 * period):该方法的作用是在指定的日期之后，按指定的间隔周期性的无限循环的执行某一任务
 * 
 * @author mahd
 *
 */
public class Main2_cancel {
	private static Timer timer = new Timer();// 运行后线程还在继续

	static public class MyTaskA extends TimerTask {

		@Override
		public void run() {
			System.out.println("A运行了！时间为" + new Date());
			// this.cancel();//TimerTask类中的cancel()方法作用是将自身从队列中清除

			timer.cancel();// Timer类中的cancel()方法作用是将任务队列中的全部任务清空

		}

	}

	static public class MyTaskB extends TimerTask {

		@Override
		public void run() {
			System.out.println("B运行了！时间为" + new Date());

		}

	}

	public static void main(String[] args) {

		// 3、任务执行时间被延迟
		try {
			MyTaskA myTask = new MyTaskA();
			MyTaskB myTask2 = new MyTaskB();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String dateString = "2018-05-16 10:55:00";
			Date dateSdf = sdf.parse(dateString);
			System.out.println("字符串时间：" + dateString + " 当前时间：" + new Date().toLocaleString());
			timer.schedule(myTask, dateSdf, 4000);
			timer.schedule(myTask2, dateSdf, 4000);
		} catch (ParseException e) {
			e.printStackTrace();
		}

	}

}
