package com.mkmd.timer.schedule1.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

/**
 * 方法schedule和方法scheduleAtFixedRate都会按顺序执行，所以不要考虑非线程安全的情况
 * 
 * 方法schedule和方法scheduleAtFixedRate的主要区别只在于不延时的情况
 * 使用schedule的方法：如果执行任务的时间没有被延时，那么下一次任务的执行时间参考的是上一次任务的开始时间来计算
 * 使用scheduleAtFixedRate的方法：如果执行任务的时间没有被延时，那么下一次任务的执行时间参考的是上一次任务的结束时间来计算
 * 延时情况则没有区别，也就是schedule或scheduleAtFixedRate方法都是如更执行任务的时间被延时，那么下一次任务的执行时间参考的上一次任务的结束时间来计算
 * 
 * @author mahd
 *
 */
public class Main5 {
	private static Timer timer = new Timer();
	private static int runcount = 0;

	static public class MyTask extends TimerTask {

		@Override
		public void run() {
			try {
				System.out.println("begin 运行了！时间为" + new Date());
				// Thread.sleep(1000);// 不延时
				Thread.sleep(5000);// 延时
				System.out.println(" end 运行了！时间为" + new Date());
				runcount++;
				if (runcount == 5) {
					timer.cancel();
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}

	}

	public static void main(String[] args) {

		try {
			MyTask myTask = new MyTask();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String dateString = "2018-05-16 09:42:00";
			Date dateSdf = sdf.parse(dateString);
			System.out.println("字符串时间：" + dateString + " 当前时间：" + new Date().toLocaleString());
			// timer.schedule(myTask, dateSdf, 3000);
			timer.scheduleAtFixedRate(myTask, dateSdf, 3000);
		} catch (ParseException e) {
			e.printStackTrace();
		}

	}

}
