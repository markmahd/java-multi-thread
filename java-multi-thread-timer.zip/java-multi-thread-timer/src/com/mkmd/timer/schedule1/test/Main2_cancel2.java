package com.mkmd.timer.schedule1.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

/**
 * schedule(TimerTask task,Date firstTime,long
 * period):该方法的作用是在指定的日期之后，按指定的间隔周期性的无限循环的执行某一任务
 * 
 * @author mahd
 *
 */
public class Main2_cancel2 {
	static int i = 0;

	static public class MyTaskA extends TimerTask {

		@Override
		public void run() {
			System.out.println("正常执行了" + i);

		}

	}

	public static void main(String[] args) {

		// Timer类中的cancel()方法有事并不一定会停止执行任务的计划，而是正常执行。
		while (true) {
			try {
				i++;
				Timer timer = new Timer();
				MyTaskA myTask = new MyTaskA();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String dateString = "2018-05-16 11:01:00";
				Date dateSdf = sdf.parse(dateString);
				timer.schedule(myTask, dateSdf);
				timer.cancel();
			} catch (ParseException e) {
				e.printStackTrace();
			}

		}
	}

}
