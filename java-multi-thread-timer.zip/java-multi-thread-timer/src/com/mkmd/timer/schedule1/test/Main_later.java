package com.mkmd.timer.schedule1.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

/**
 * schedule(TimerTask task,Date time):该方法的作用是在指定的日期执行一次某任务
 * 
 * @author mahd
 *
 */
public class Main_later {
	private static Timer timer = new Timer();// 运行后线程还在继续
	// private static Timer timer = new Timer(true);//程序运行后迅速结束当前进程,TimerTask任务不再运行

	static public class MyTask extends TimerTask {

		@Override
		public void run() {
			try {
				System.out.println("1 begin 运行了！时间为" + new Date());
				Thread.sleep(20000);
				System.out.println("1 end 运行了！时间为" + new Date());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}

	}

	static public class MyTask2 extends TimerTask {

		@Override
		public void run() {
			System.out.println("2 begin 运行了！时间为" + new Date());
			System.out.println("运行了！时间为" + new Date());
			System.out.println("2 end 运行了！时间为" + new Date());

		}

	}

	public static void main(String[] args) {

		// 3、多个TimerTask任务及延时测试
		try {
			MyTask myTask = new MyTask();
			MyTask2 myTask2 = new MyTask2();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String dateString = "2018-05-16 10:02:00";
			String dateString2 = "2018-05-16 10:02:05";
			Date dateSdf = sdf.parse(dateString);
			Date dateSdf2 = sdf2.parse(dateString2);
			System.out.println("字符串1时间：" + dateString + " 当前时间：" + new Date().toLocaleString());
			System.out.println("字符串2时间：" + dateString2 + " 当前时间：" + new Date().toLocaleString());
			timer.schedule(myTask, dateSdf);
			timer.schedule(myTask2, dateSdf2);
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

}
