package com.mkmd.lock.reentrantLock2.test;

/***
 * 
 * 在使用notify/notifyAll方法进行通知时，被通知的线程确实由JVM随机选择的。但使用ReentrantLock结合condition类时可以实现“选择性通知”，
 * 在Condition勒种默认提供的。
 * 而synchronized就相当于整个Lock对象中只有一个单一的Condition对象，所有线程都注册在它一个对象身上。
 * 线程开始notifyAll时，需要通知所有的WAITING线程，没有选择权，会出现相当大的效率问题
 * 
 * 注意：必须在Condition类await方法调用之前用Lock的lock方法获得同步监视器
 * 
 * Object类中的wait方法相当于Condition类中的await方法。 Object类中的wait(long
 * timeout)方法相当于Condition类中的await(long time,TimeUnit unit)方法。
 * Object类中的notify方法相当于Condition类中的signl方法。
 * Object类中的notifyAll方法相当于Condition类中的signlAll方法。
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) throws InterruptedException {
		MyService service = new MyService();
		ThreadA a = new ThreadA(service);
		a.start();
		Thread.sleep(3000);
		service.signl();
	}

}
