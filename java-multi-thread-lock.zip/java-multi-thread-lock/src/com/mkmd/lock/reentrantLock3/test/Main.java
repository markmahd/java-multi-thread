package com.mkmd.lock.reentrantLock3.test;

/***
 * 
 * 使用ReentrantLock对象可以唤醒指定种类的线程，这是控制部分线程行为的方便方式
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) throws InterruptedException {
		MyService service = new MyService();
		ThreadA a = new ThreadA(service);
		a.setName("A");
		a.start();
		ThreadB b = new ThreadB(service);
		b.setName("B");
		b.start();
		Thread.sleep(3000);
		service.signlAll_A();
	}

}
