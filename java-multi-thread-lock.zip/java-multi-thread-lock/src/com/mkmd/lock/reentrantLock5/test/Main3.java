package com.mkmd.lock.reentrantLock5.test;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/**
 * ReentrantLock常用方法：
 * 
 * int getHoldCount():查询当前线程保持次锁定的个数，也就是调用lock()方法的次数
 * 
 * int getQueueLength():返回正等待获取此锁定的线程估计数
 * 
 * int getWaitQueueLength(Condition condition):返回等待与此锁定相关的给定条件Condition的线程估计数
 * 
 * boolean hasQueueTHread(Thread thread):查询指定的线程是否正在等待获取此锁定
 * 
 * boolean hasWaiters(Condition condition):查询是否有线程正在等待与此锁定有关的Condition条件
 * 
 * boolean isFair():判断是不是公平锁
 * 
 * boolean isHeldByCurrentThread():查询当前线程是否保持此锁定
 * 
 * boolean IsLocked():查询此锁定是否由任意线程保持
 * 
 * void lockInterruptibly():如果当前线程未被中断，则获取锁定，如果已经被中断则出现异常
 * 
 * boolean tryLock():仅在调用时锁定未被另一个线程保持的情况下，才获取锁定
 * 
 * boolean tryLock(long timeout,TimeUnit
 * unit):如果锁定在给定等待时间内没有被另一个线程保持，且当前线程未被中断，则获取该锁定
 * 
 * awaitUninterruptibly():可以等待异步执行的结果返回
 * 
 * awaitUntil(long timeout):线程在等待时间到达前，可以被其他线程提前唤醒
 * 
 * Condition对象可以对线程执行的业务进行排序规划
 * 
 * @author mahd
 *
 */
public class Main3 {
	volatile private static int nextPrintWho = 1;
	private static ReentrantLock lock = new ReentrantLock();
	final private static Condition CONDITIONA = lock.newCondition();
	final private static Condition CONDITIONB = lock.newCondition();
	final private static Condition CONDITIONC = lock.newCondition();

	public static void main(String[] args) {
		Thread threadA = new Thread() {

			@Override
			public void run() {
				try {
					lock.lock();
					while (nextPrintWho != 1) {
						CONDITIONA.await();
					}
					for (int i = 0; i < 3; i++) {
						System.out.println("ThreadA" + (i + 1));

					}
					nextPrintWho = 2;
					CONDITIONB.signalAll();
				} catch (InterruptedException e) {
					e.printStackTrace();
				} finally {
					lock.unlock();
				}
			}

		};
		Thread threadB = new Thread() {

			@Override
			public void run() {
				try {
					lock.lock();
					while (nextPrintWho != 2) {
						CONDITIONB.await();
					}
					for (int i = 0; i < 3; i++) {
						System.out.println("ThreadB" + (i + 1));

					}
					nextPrintWho = 3;
					CONDITIONC.signalAll();
				} catch (InterruptedException e) {
					e.printStackTrace();
				} finally {
					lock.unlock();
				}
			}

		};
		Thread threadC = new Thread() {

			@Override
			public void run() {
				try {
					lock.lock();
					while (nextPrintWho != 3) {
						CONDITIONC.await();
					}
					for (int i = 0; i < 3; i++) {
						System.out.println("ThreadC" + (i + 1));

					}
					nextPrintWho = 1;
					CONDITIONA.signalAll();
				} catch (InterruptedException e) {
					e.printStackTrace();
				} finally {
					lock.unlock();
				}
			}

		};

		Thread[] aArray = new Thread[5];
		Thread[] bArray = new Thread[5];
		Thread[] cArray = new Thread[5];
		for (int i = 0; i < 5; i++) {
			aArray[i] = new Thread(threadA);
			bArray[i] = new Thread(threadB);
			cArray[i] = new Thread(threadC);
			aArray[i].start();
			bArray[i].start();
			cArray[i].start();

		}
	}

}
