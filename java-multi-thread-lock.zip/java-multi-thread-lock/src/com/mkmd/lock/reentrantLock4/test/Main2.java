package com.mkmd.lock.reentrantLock4.test;

/***
 * 
 * 实现生产者/消费者模式：多对多交替打印
 * 
 * @author mahd
 *
 */
public class Main2 {

	public static void main(String[] args) throws InterruptedException {
		MyService2 service = new MyService2();
		ThreadA2[] a = new ThreadA2[10];
		ThreadB2[] b = new ThreadB2[10];
		for (int i = 0; i < 10; i++) {
			a[i] = new ThreadA2(service);
			b[i] = new ThreadB2(service);
			a[i].start();
			b[i].start();
		}
	}

}
