package com.mkmd.lock.reentrantLock4.test;

/***
 * 
 * 实现生产者/消费者模式：一对一交替打印
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) throws InterruptedException {
		MyService service = new MyService();
		ThreadA a = new ThreadA(service);
		a.start();
		ThreadB b = new ThreadB(service);
		b.start();
	}

}
