package com.mkmd.lock.reentrantLock4.test;

public class ThreadA2 extends Thread {
	private MyService2 service;

	public ThreadA2(MyService2 service) {
		super();
		this.service = service;
	}

	@Override
	public void run() {
		for (int i = 0; i < Integer.MAX_VALUE; i++) {
			service.set();
		}
	}

}
