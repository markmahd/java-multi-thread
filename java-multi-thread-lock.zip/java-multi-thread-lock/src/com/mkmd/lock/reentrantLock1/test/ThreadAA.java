package com.mkmd.lock.reentrantLock1.test;

public class ThreadAA extends Thread {
	private MyService service;

	public ThreadAA(MyService service) {
		super();
		this.service = service;
	}

	@Override
	public void run() {
		service.methodA();
	}

}
