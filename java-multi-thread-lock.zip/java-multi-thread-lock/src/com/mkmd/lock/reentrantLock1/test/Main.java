package com.mkmd.lock.reentrantLock1.test;

/***
 * 
 * 调用lock()代码的线程就持有类“对象监视器”，其他线程只有等待锁被释放再次争抢。
 * 效果和使用synchronized关键字一样，线程之间还是顺序执行的。
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) throws InterruptedException {
		MyService service = new MyService();
		ThreadA a = new ThreadA(service);
		a.setName("a");
		a.start();
		ThreadAA aa = new ThreadAA(service);
		aa.setName("aa");
		aa.start();
		Thread.sleep(100);
		ThreadB b = new ThreadB(service);
		b.setName("b");
		b.start();
		ThreadBB bb = new ThreadBB(service);
		bb.setName("bb");
		bb.start();
	}

}
