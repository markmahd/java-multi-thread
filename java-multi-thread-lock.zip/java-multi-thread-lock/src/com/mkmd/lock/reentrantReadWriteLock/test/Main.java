package com.mkmd.lock.reentrantReadWriteLock.test;

/**
 * 读写锁标识也有两个锁，一个是读操作相关的锁，也成为共享锁；另一个是写操作相关的锁，也叫排它锁。 也就是多个读锁之间不互斥，读锁和写锁互斥，写锁和写锁互斥
 * 
 * @author mahd
 *
 */
public class Main {

	public static void main(String[] args) {

		// 读读是异步的，不排斥
		// Service service = new Service();
		// ThreadR r1 = new ThreadR(service);
		// ThreadR r2 = new ThreadR(service);
		// r1.setName("a");
		// r2.setName("b");
		// r1.start();
		// r2.start();

		// 写写是同步的，互斥
		// Service service = new Service();
		// ThreadW w1 = new ThreadW(service);
		// ThreadW w2 = new ThreadW(service);
		// w1.setName("a");
		// w2.setName("b");
		// w1.start();
		// w2.start();

		// 读写是同步的，互斥
		// Service service = new Service();
		// ThreadR r1 = new ThreadR(service);
		// ThreadW w2 = new ThreadW(service);
		// r1.setName("a");
		// w2.setName("b");
		// r1.start();
		// w2.start();

		// 写读是同步的，互斥
		Service service = new Service();
		ThreadW w1 = new ThreadW(service);
		ThreadR r2 = new ThreadR(service);
		w1.setName("a");
		r2.setName("b");
		w1.start();
		r2.start();

	}

}
