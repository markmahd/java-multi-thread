package com.mkmd.lock.reentrantReadWriteLock.test;

public class ThreadW extends Thread {
	private Service service;

	public ThreadW(Service service) {
		super();
		this.service = service;
	}

	@Override
	public void run() {
		service.write();
	}

}
